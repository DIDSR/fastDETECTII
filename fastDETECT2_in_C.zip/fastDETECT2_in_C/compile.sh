#!/bin/bash

gcc -g fastDETECT2.c -o fastDETECT2.x -lgsl -lgslcblas -lm
