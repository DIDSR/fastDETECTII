######################################################################
 			DISCLAIMER
######################################################################

This software and documentation (the "Software") were developed at the Food and Drug Administration (FDA) by employees of the Federal Government in the course of their official duties. Pursuant to Title 17, Section 105 of the United States Code, this work is not subject to copyright protection and is in the public domain. Permission is hereby granted, free of charge, to any person obtaining a copy of the Software, to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, or sell copies of the Software or derivatives, and to permit persons to whom the Software is furnished to do so. FDA assumes no responsibility whatsoever for use by other parties of the Software, its source code, documentation or compiled executables, and makes no guarantees, expressed or implied, about its quality, reliability, or any other characteristic. Further, use of this code in no way implies endorsement by the FDA or confers any advantage in regulatory decisions. Although this software can be redistributed and/or modified freely, we ask that any derivative works bear some notice that they have been modified.


File:    	README.txt (fastDETECT2)
Authors:  	Diksha Sharma (Diksha.Sharma@fda.hhs.gov)
		Aldo Badano (Aldo.Badano@fda.hhs.gov)
Date:    	Apr 30, 2015


######################################################################



****************************************************************************************************
			INTRODUCTION
****************************************************************************************************

fastDETECT2 is a new and improved version of the DETECT2 (optical transport used in MANTIS).  It models the optical transport in x-ray detectors with columnar scintillators. It uses a file containing the energy and location of individual energy deposition events as input.  It generates the optical transport statistics including total number of optical photons generated, detected, lost at the column boundaries, or absorbed in the top of the detector or in the bulk.  It also reports the average path length for transport.  fastDETECT2 outputs the point response function image, pulse height spectrum, and the number of optical photons detected per primary x-ray history.  The source code is written in C.
 
More details about the physics and novel features of fastDETECT2 are available at: 
"D. Sharma, A. Badal and A. Badano; hybridMANTIS: a CPU-GPU Monte Carlo method for modeling indirect x-ray detectors with columnar scintillators; Physics in Medicine and Biology, 57(8), pp. 2357-72 (2012)."




****************************************************************************************************
			RANDOM NUMBER GENERATORS (RNG)
****************************************************************************************************

fastDETECT2 uses two random number generators.  It uses GNU scientific library function calls for sampling (Poisson) the number of optical photons based on light yield and deposited energy for that particular event.  In addition, we use ranecu pseudo-RNG for optical photon transport.  For each energy deposition event, the generator is initialized far away from previous history (using leap frog technique) position so that non-correlated random numbers are generated.  For details, please read A Badal and J Sempau, Computer Physics Communications 175 (2006) p. 440-450.




****************************************************************************************************
			INPUT ARGUMENTS
****************************************************************************************************

There are total 13 arguments to be supplied (in below order) through the command line.  They should be each separated by a blank space.  

1.	Thickness (�m)
2.	Radius of columns (�m)
3.	Top surface absorption fraction (between 0 and 1)
4.	Bulk absorption coefficient (�m-1) (eg: 1e-4)
5.	Roughness coefficient (between 0.01 and 0.5)
6.	Sensor reflectivity (as floating point number) (eg: 25% will be entered as 0.25)
7.	Total number of primaries to be simulated
8.	Number of bins used for generating the pulse height spectrum (PHS)
9.	Initial seed to be used for random number generator (RNG) � for initializing the ranecu RNG used for optical photon transport.
10.	Energy deposition file name (Input)
11.	Point response function image file name (Output)
12.	PHS file name (Output)
13.	Number of detected optical photons per primary file name (Output)


A number of parameters have been hard coded in fastDETECT2.c.  They include:

�	Detector lateral dimensions = 909 x 909 �m2
�	Refractive index of scintillator columns = 1.8
�	Refractive index of inter-columnar gap = 1.0
�	Minimum and maximum distance an optical photon can travel when transmitted from a column = min 1 um, max 280 um. (This comes from one of the features of fastDETECT2 called on-the-fly geometry.  Once an optical photon exits a column, it samples distance to the next column uniformly between the min and max distances specified here.  For more information, please read our paper published in PMB 2012.)
�	Point response function image lower bounds (x, y) = (0, 0) �m
�	Point response function image upper bounds (x, y) = (909, 909) �m
�	Light yield (/eV) = 0.055
�	Pixel pitch = 9 �m
�	Minimum and maximum number of optical photons detected to be included in PHS = min 0, max 5000. (If the number of detected photons exceed max value, they will be aggregated in the last bin.  The number of bins is inputted by the user.  Bin size = round[(max-min)/number of bins].)




****************************************************************************************************
			INPUT AND OUTPUT FILES
****************************************************************************************************

fastDETECT2 requires one input file and generates three output files.  The input file contains the location, energy and x-ray history number of the energy deposition events.  The order should be x, y, z, energy, x-ray history number.  x, y, z should be in cm and energy in eV.  For each x-ray interaction, all the energy deposition event information is listed in this format, with each event starting a new line.  fastDETECT2 recognizes the end of an x-ray history by searching for # symbol.  For instance, a file with two x-ray histories may look as follows:  

4.598436841E-02  4.456798661E-02 -6.058012811E-03   2.5000E+04   1
4.598427193E-02  4.456799402E-02 -6.057901975E-03   6.4278E+01   1
4.598425612E-02  4.456799896E-02 -6.057882450E-03   6.0145E+01   1
4.598414321E-02  4.456799981E-02 -6.057783738E-03   4.1207E+00   1
�
# Past hist = 	1 

3.453936841E-02  1.756798661E-02 -2.056012811E-03   1.5000E+03   2
2.324271936E-02  2.956799402E-02 -2.043901975E-03   4.4278E+01   2
3.342425612E-02  1.756799896E-02 -1.042882450E-03   6.0145E+00   2
3.123414321E-02  1.356799981E-02 -1.003783738E-03   7.1207E+00   2
�
# Past hist = 	2 

  
The three output files include: point response function image, pulse height spectrum, and number of detected optical photons per primary.  Point response function image outputs the image based on the lower and upper bounds of x and y hard coded.  Currently it is set to be the entire detector area, however if the user wishes to modify this, they can go to fastDETECT2.c and search for �initialize rest of the parameters�, make changes to lbound_x/y and ubound_x/y and re-compile.  One of the file outputs list the number of detected optical photons per primary history in list mode.  This data is binned based on the number of bins provided by the user in the input arguments and the hard coded values of min and maximum optical photons to be binned, to obtain the pulse height spectrum.



****************************************************************************************************
			CODE COMPILATION AND EXECUTION
****************************************************************************************************

The code can be compiled by running ./compile.sh.  gcc and GNU scientific library packages have to be installed prior to compiling.  The current version of fastDETECT2 has been tested with gcc version 4.8.2 and GNU scientific library version 1.16.  The compilation will generate fastDETECT2.x executable.  A pre-compiled executable (on Linux platform) is included in the folder.

Execution: ./fastDETECT2.x command line arguments separated by a blank space.

Example:  ./fastDETECT2.x 150 5.1 0.1 1e-4 0.2 0.25 1000 400 2415364 CsI_deposition_events.dat PRF.out PHS.out DPP.out

	

****************************************************************************************************
			DEMO CASE
****************************************************************************************************

The following case can be run as a demo to verify that the code is working properly.  
There is a sample input file named �CsI_deposition_events.dat� included in the folder.  This file was generated using PENELOPE 2006 (F. Salvat, J. Fernandez-Varea, and J. Sempau. PENELOPE-2006: A code system for Monte Carlo simulation of electron and photon transport. NEA-OECD, available at 
http://www.oecd-nea.org/science/pubs/2006/nea6222-penelope.pdf, 2006), using 25 keV monoenergetic x-ray beam (point source) incident at the center of the detector (dimensions 909 x 909 x 150 �m3), and 1e4 x-ray histories were simulated.  Please note that maximum 1e4 histories (input argument: total number of primaries to be simulated) can be simulated using this file.

Input arguments:
1. 	Thickness = 150 �m.
2. 	Radius of columns = 5.1 �m.
3. 	Top surface absorption fraction = 0.1 (modeling almost ideal reflector).
4. 	Bulk absorption coefficient = 1e-4 �m-1.
5. 	Roughness coefficient = 0.2.
6. 	Sensor reflectivity = 0.25.
7. 	Total number of primaries to be simulated = 1000.
8. 	Number of bins used for generating the PHS = 400.
9. 	Initial seed to be used for RNG = 2415364.
10. 	Energy deposition file name = CsI_deposition_events.dat.
11. 	Point response function image file name = PRF.out.
12. 	PHS file name = PHS.out.
13. 	Number of detected optical photons per primary file name = DPP.out.


One should expect to see the below optical transport statistics on the console (these are also reported in sample-output.txt):


********************************************************************
		OPTICAL TRANSPORT STATISTICS
********************************************************************
	Total number of photons:
		 Generated: 		 2325690
		 Detected: 		 1485981
		 Absorbed at top: 	 208974
		 Absorbed in bulk: 	 42729
		 Lost at the boundary: 	 586550
	 Average path length (microns):  569.258362
	 Total time (seconds): 		 85.247794
	 Speed (primaries/seconds): 	 11.730509
********************************************************************





****************************************************************************************************
			COMPUTATIONAL SPEED
****************************************************************************************************

fastDETECT2 was run on a computer comprising of four Intel Core i5-3570 CPU cores, and the following information was collected.  This is to give the user an idea of what to expect on similar systems, however the speeds may slightly vary depending on the randomness of the optical transport, the CPU processor and the computational load on the system.

10000 x-ray histories � 13 hist/sec.
1000 x-ray histories � 12 hist/sec.
100 x-ray histories � 11 hist/sec.



****************************************************************************************************
			PACKAGE CONTENTS
****************************************************************************************************


1.	fastDETECT2.c � main C program.
2.	kernel.c � this C file contains all the optical transport routines for fastDETECT2.
3.	fastDETECT2.x � executable.
4.	compile.sh � bash script containing the command to compile.
5.	CsI_deposition_events.dat � sample energy deposition events file to be provided as an input to fastDETECT2.x.  For details, see section �Input and output files� above.
6.	sample-cmdlineargs.txt � file contains sample input arguments which can be used to test the program execution.
7.	sample_output.txt � contains the standard output that is written on the console when using the arguments in section �Code compilation and execution�.
8.	PRF.out � point response function image output file when using above arguments (using 1000 x-ray histories).
9.	PHS.out � pulse height spectrum output file when using above arguments.
10.	DPP.out � number of detected optical photons per primary output file when using above arguments.
11.	PRF.png � PRF.out image plotted using gnuplot.
12.	PHS.png � PHS.out plotted using gnuplot.
13.	DPP.png � DPP.out plotted using gnuplot.
14.	PRF.gnu - gnuplot script for plotting PRF.  Just type: load 'PRF.gnu'. (Plots PRF.out file, and saves as png.  If the filename is different, edit it within the script.)
15.	PHS.gnu - gnuplot script for PHS.
16.	DPP.gnu - gnuplot script for DPP.
17.	Quick-start-guide.txt - Quick start guide for users.  Not as comprehensive as this Readme file.
18.	README.txt � this file.



****************************************************************************************************
			CONTACT US
****************************************************************************************************

Any questions or comments should be directed to Diksha Sharma (Diksha.Sharma@fda.hhs.gov) or Aldo Badano (Aldo.Badano@fda.hhs.gov).
