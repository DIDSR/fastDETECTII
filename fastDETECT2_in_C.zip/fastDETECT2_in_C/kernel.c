///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 			     //////////////////////////////////////////////////////////
//  			     //							     //
		     //
// 			     //   	  fastDETECT2 kernel -  C        	     //
//			     //		   (optical photons transport)		     //
//			     //							     //
//			     //////////////////////////////////////////////////////////
//
// 
//
//
// ****Disclaimer****
//  This software and documentation (the "Software") were developed at the Food and Drug Administration (FDA) by employees of the Federal Government in
//  the course of their official duties. Pursuant to Title 17, Section 105 of the United States Code, this work is not subject to copyright protection
//  and is in the public domain. Permission is hereby granted, free of charge, to any person obtaining a copy of the Software, to deal in the Software
//  without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, or sell copies of the
//  Software or derivatives, and to permit persons to whom the Software is furnished to do so. FDA assumes no responsibility whatsoever for use by other
//  parties of the Software, its source code, documentation or compiled executables, and makes no guarantees, expressed or implied, about its quality,
//  reliability, or any other characteristic. Further, use of this code in no way implies endorsement by the FDA or confers any advantage in regulatory
//  decisions. Although this software can be redistributed and/or modified freely, we ask that any derivative works bear some notice that they are
//  derived from it, and any modified versions bear some notice that they have been modified. 
//
//
//	Associated publication: Sharma Diksha, Badal Andreu and Badano Aldo, "hybridMANTIS: a CPU-GPU Monte Carlo method for modeling indirect x-ray detectors with
//				columnar scintillators". Physics in Medicine and Biology, 57(8), pp. 2357-2372 (2012)
//
//
//	File:   	kernel.c 			
//	Author: 	Diksha Sharma (US Food and Drug Administration)
//	Email: 		diksha.sharma@fda.hhs.gov			
//	Last updated:  	Mar 24, 2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////
//
//      Header libraries
//
/////////////////////////////////////////

	#include <math.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <sys/time.h>
	#include <time.h>

/////////////////////////////////////////
//
//       Constants
//
/////////////////////////////////////////

	#define twopipen 6.283185308	// 2*PI
	#define pi 3.14159265		// PI
	#define epsilon 8.1929093e-6	// a very small number for float comparisons


/////////////////////////////////////////////////////////////////////////////////////
//
//     Data structure for storing a scintillation event location and deposited energy
//
/////////////////////////////////////////////////////////////////////////////////////

	struct start_info
	{
		double str_x;		// x-coordinate
		double str_y;		// y-coordinate
		double str_z;		// z-coordinate
		double str_E;		// deposited energy
		int str_histnum;	// x-ray history #
		int str_N;		// # of optical photons to be transported for this energy
	};

/////////////////////////////////////////
//
//       Function declarations
//
/////////////////////////////////////////

// transports optical photon from its generation until it ends (detected/absorbed/lost).
		int algo(float *normal, float *old_pos, float *pos, float *dcos, unsigned long long int *num_rebound, int* seed, struct start_info info, 
		unsigned long long int *myimage, float xdetector, float ydetector, float R, float H, float n1, float n2, float top_absfrac, float bulk_abscoeff, float beta, 
		float d_min, int pixelsize, float lbound_x, float lbound_y, float ubound_x, float ubound_y, float sensorRefl, float d_max, int ydim, int *h_num_detected_prim);

// photon within a column. calculate if it gets absorbed or moves inside the column.
		int isotropic(float *pos, float *dcos, int* seed, float bulk_abscoeff, float R, float H, float xdetector, float ydetector, struct start_info info, 
		unsigned long long int mynum_rebound);

// photon within a column. calculate distance to next position in the same column and move it.
		float dist_to_surface(float *pos, float *dcos, float R, float H, float xdetector, float ydetector, struct start_info info, unsigned long long int mynum_rebound);

// photon within/between columns. calculate if it gets reflected or transmitted.
		int boundary_analysis(float *normal, float *pos, float *dcos, int* seed, float xdetector, float ydetector, float R, float H, float n1, float n2, float top_absfrac, 			float beta, float d_min, int pixelsize, float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, struct start_info info, 
		float d_max, float sensorRefl, int ydim, int *h_num_detected_prim);	

// transmit photon to another column. calculates the new position when it transmits, build new column and move photon here.
		int transmit(float *pos, float *dcos, float *normal, int* seed, float xdetector, float ydetector, float H, float top_absfrac, float beta, float d_min, int pixelsize, 			float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, struct start_info info, float d_max, float sensorRefl, int ydim, 
		int flagCCT, int *h_num_detected_prim);	

// called when photon reflects from sensor plane (bottom surface) of the detector, outside of any column.
		int refl_bottom(float *pos, float *dcos, float *normal, float xdetector, float ydetector, int* seed, float beta, float d_min, float H, float d_max);	

// calculate dot product of two vectors to give cosine of angle between them.
		float dot_product(float *aa, float *b);	

// determine if photon got detected at sensor plane or is reflected back within the column
		int detection(float *pos, float H, int pixelsize, float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, 
		struct start_info info, float sensorRefl, float d_min, int* seed, float *dcos, float *normal, float bulk_abscoeff, float R, float xdetector, float ydetector, 
		unsigned long long int mynum_rebound, int ydim, int *h_num_detected_prim); 

// calculate directional cosines of reflected/refracted vector.
		void trans_dir_cos(float *dcos, float *normal, float refl_theta, float trans_theta, int flag_ref, struct start_info info);

// calculate new rough normal vector depending on value of 'beta' (roughness coefficient).
		void RoughSurface(float *normal, int* seed, float beta); 

// RANECU pseudo random number generator
		void init_PRNG(int history_batch, int histories_per_thread, int seed_input, int* seed);
		int abMODm(int m, int a, int s);
		float ranecu(int* seed);

/////////////////////////////////////////
//
//       Global variables
//
/////////////////////////////////////////

		// counters
		unsigned long long int num_generated=0;	
		unsigned long long int num_detect=0;	
		unsigned long long int num_abs_top=0;	
		unsigned long long int num_abs_bulk=0;	
		unsigned long long int num_lost=0;	
		unsigned long long int num_outofcol=0;	 
		unsigned long long int local_counter=0;	 	// total number of photons terminated (either detected at sensor, absorbed at the top or in the bulk)
		unsigned long long int num_theta1=0;	

		//flags
		int absorbed=0;					// flag for photons absorbed at the top surface of the detector
		int detect=0;					// flag for photons detected at the sensor plane of the detector
		int bulk_abs=0;					// flag for photons absorbed in the bulk of a column

		float Xc=0.0f;					// center coordinates (x,y) of the current cylinder
		float Yc=0.0f;
		float photon_distance=0.0f;     		// total distance travelled by all the photons

		FILE *fp1;

/////////////////////////////////////////
//
//    Functions definition
//
/////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// transports optical photon from its generation until it ends (detected/absorbed/lost).
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int algo(float *normal, float *old_pos, float *pos, float *dcos, unsigned long long int *num_rebound, int* seed, struct start_info info, unsigned long long int *myimage, 
	float xdetector, float ydetector, float R, float H, float n1, float n2, float top_absfrac, float bulk_abscoeff, float beta, float d_min, int pixelsize, float lbound_x, 
	float lbound_y, float ubound_x, float ubound_y, float sensorRefl, float d_max, int ydim, int *h_num_detected_prim)
	{

		float rr=0.0f, theta=0.0f, norm = 0.0f;		// used in calculating directional cosines
		float rnd_num = 0.0f;
		int myresult = 0;				// flag to check if the photon is terminated (yes=1; no=0)

		if(absorbed == 0)   		// not absorbed at the top surface of detector, check for absorption in the bulk and detection       
		 {
			bulk_abs = isotropic(pos, dcos, seed, bulk_abscoeff, R, H, xdetector, ydetector, info, num_rebound[local_counter]);

			if(bulk_abs == 0)	// not absorbed in the bulk, check for detection
			{
				detect = detection(pos, H, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, myimage, info, sensorRefl, d_min, seed, dcos, normal, bulk_abscoeff, R, xdetector, ydetector, num_rebound[local_counter], ydim, h_num_detected_prim);
			}
		 }

		 
		if( (detect == 1) || (absorbed == 1) || (bulk_abs == 1) )	// photon terminated
		 {
			local_counter++;				// increment the photon counter

			// calculate directional cosines
			rnd_num = (ranecu(seed) * 2.0f) - 1.0f; 	// generate random number between (-1,1)	 	

			dcos[2] = rnd_num;				// generate random number between (-1,1)
			rr = sqrt(1.0-rnd_num*rnd_num);
			theta=ranecu(seed)*twopipen;			// generate random number between 0 and 2pi
			dcos[0]=rr*cos(theta);
			dcos[1]=rr*sin(theta);

			// normalize
			norm = sqrt(dcos[0]*dcos[0] + dcos[1]*dcos[1] + dcos[2]*dcos[2]);

			if ((norm < (1.0f - epsilon)) || (norm > (1.0f + epsilon)))
			 {
				dcos[0] = dcos[0]/norm;
				dcos[1] = dcos[1]/norm;
				dcos[2] = dcos[2]/norm;
			 }


			pos[0] = info.str_x; pos[1] = info.str_y; pos[2] = info.str_z;	// set starting location of photon based on the PENELOPE scintillation events buffer
			old_pos[0] = info.str_x; old_pos[1] = info.str_y; old_pos[2] = info.str_z;
			normal[0] = 0.0f; normal[1] = 0.0f; normal[2] = 0.0f;		// initialize normal vector
	
			if(beta > 0.0f)
				RoughSurface(normal, seed, beta);	// perturb smooth normal according to 'beta' 

			absorbed = 0;
			detect = 0;
			bulk_abs = 0;

			myresult = 1;		// flag for photon termination

		 }
		else if( (detect == 0) && (absorbed == 0) && (bulk_abs == 0) && (fabs(dcos[2] - 0.0f) < epsilon) )  // check for trapped photon going back and forth dcos(z)=0
		 {
			// kill the photon and generate a new one instead - do not increment the counter

			// re-compute directional cosines
			rnd_num = (ranecu(seed) * 2.0f) - 1.0f; 
		 	
			dcos[2] = rnd_num;		
			rr = sqrt(1.0-rnd_num*rnd_num);
			theta=ranecu(seed)*twopipen;
			dcos[0]=rr*cos(theta);
			dcos[1]=rr*sin(theta);

			norm = sqrt(dcos[0]*dcos[0] + dcos[1]*dcos[1] + dcos[2]*dcos[2]);

			if ((norm < (1.0f - epsilon)) || (norm > (1.0f + epsilon)))
			 {
				dcos[0] = dcos[0]/norm;
				dcos[1] = dcos[1]/norm;
				dcos[2] = dcos[2]/norm;
			 }

			pos[0] = info.str_x; pos[1] = info.str_y; pos[2] = info.str_z;
			normal[0] = 0.0f; normal[1] = 0.0f; normal[2] = 0.0f;
	
			if(beta > 0.0f)
				RoughSurface(normal, seed, beta);	

			absorbed = 0;
			detect = 0;
			bulk_abs = 0;

			myresult = 0;	// photon still alive
		 }
		else
		 {
			num_rebound[local_counter]++;	// increment the number of rebounds this photon undergoes from columnar walls
		    	absorbed = boundary_analysis(normal, pos, dcos, seed, xdetector, ydetector, R, H, n1, n2, top_absfrac, beta, d_min, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, myimage, info, d_max, sensorRefl, ydim, h_num_detected_prim);

			myresult = 0;	// photon still alive
		 }

	return myresult;

	}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// determine where photon hits next within the column or if it gets absorbed in the material
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int isotropic(float *pos, float *dcos, int* seed, float bulk_abscoeff, float R, float H, float xdetector, float ydetector, 
	struct start_info info, unsigned long long int mynum_rebound)
	{
		float dsurf = 999.0f;		// distance to surface
		float dabs = 999.0f;		// distance to bulk absorption
		int flag_bulkabs = 0;		// flag to check if photon absorbed in the bulk

		dsurf = dist_to_surface(pos, dcos, R, H, xdetector, ydetector, info, mynum_rebound);	// distance to surface

		if (bulk_abscoeff > 0.0f)	
			dabs = (-1.0f/bulk_abscoeff) * log(ranecu(seed));				// distance to absorption
		else
			dabs = 999999.0f;

		if (fabs(dsurf-(-99.0f)) < epsilon)				// photon lost: goes out of detector boundaries in dist_to_surface() function
		{
			flag_bulkabs = 1;
		}
		else if ( (dsurf < dabs) && (dsurf >= 0.0f) )			// photon not absorbed
		 {		
			flag_bulkabs = 0;
		 }
		else if ( (dsurf >= dabs) && (dsurf >= 0.0f) )			// photon absorbed
		 {
			flag_bulkabs = 1;

			num_abs_bulk++;						// increment to the number of optical photons absorbed in the bulk
		 }

	   return flag_bulkabs;
	}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// calculate distance to surface (within same column)
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	float dist_to_surface(float *pos, float *dcos, float R, float H, float xdetector, float ydetector, struct start_info info, 
	unsigned long long int mynum_rebound)
	{
		float d=999.0f;				// distance to surface walls
		float d1=999.0f, d2=999.0f;
		float d_plane=999.0f, d_cyl=999.0f;	// distance to z-plane; to surface walls of the cylinder column
		float temp_pos[3] = {0.0f};
		float my1[3] = {0.0f};
		float R1 = 999.0f, R2 = 999.0f;
		float stepsize = 0.5f;			// used for moving the photon towards the column, if it goes outside due to precision errors.
		int repeat = 0, ctr1 = 0; 		// number of times photon should be moved in steps towards the column before killing. In this code maximum steps = 100.
							// Valid only when goes out of column.

		// store current position in a temporary variable
		temp_pos[0] = pos[0];
		temp_pos[1] = pos[1];
		temp_pos[2] = pos[2];

		// center of first column (assumed as x,y coordinates of the energy deposition event from Penelope)
		if(mynum_rebound == 0)				
		{
			Xc = info.str_x;
			Yc = info.str_y;
		}

		// solving quadratic equation for distance from a point to the surface of cylinder
		my1[0] = dcos[0]*dcos[0] + dcos[1]*dcos[1];
		my1[1] = 2.0f*( ((pos[0]-(Xc))*dcos[0]) + ((pos[1]-(Yc))*dcos[1]) );
		my1[2] = (pos[0]-(Xc))*(pos[0]-(Xc)) + (pos[1]-(Yc))*(pos[1]-(Yc)) - (R*R);
	
		// actual distance d = (d1 or d2)/sin_theta2	
		d1 = (-my1[1] + (sqrt( (my1[1]*my1[1]) - (4.0f*my1[0]*my1[2]) )))/(2.0f * my1[0]);
		d2 = (-my1[1] - (sqrt( (my1[1]*my1[1]) - (4.0f*my1[0]*my1[2]) )))/(2.0f * my1[0]);

	
		// hits either upper half surface or top surface of cylinder
		if(dcos[2] > 0.0f) 
		 {

		  if((fabs(dcos[0] - 0.0f) < epsilon) && (fabs(dcos[1] - 0.0f) < epsilon) && (fabs(dcos[2] - 1.0f) < epsilon))  
		  // if photon travel straight in +z axis direction
		   {
			d = (H/2.0f - pos[2])/dcos[2];

			pos[2] = H/2.0f;	

			pos[0] = temp_pos[0] + d*dcos[0];
			pos[1] = temp_pos[1] + d*dcos[1];
		   }
		  else
		   {		

			// calculate distance to infinite plane at z=H/2
			d_plane = (H/2.0f - pos[2])/(dcos[2]);

			// calculate the distance to the upper half of the cylinder
			if(d1 >= d2) 
			{
				d_cyl = d1;
			}
			else if(d2 > d1)
			{
				d_cyl = d2;
			}

			// find min from d_plane and d_cyl
			if(d_plane >= d_cyl)
			 {
				d = d_cyl;
				pos[2] = temp_pos[2] + d*dcos[2];
			 }
			else
			 {
				d = d_plane;		
				pos[2] = H/2.0f;
			 }

			pos[0] = temp_pos[0] + d*dcos[0];
			pos[1] = temp_pos[1] + d*dcos[1];

		   }	// else loop ends
	
		
		 } // if loop for dcos[2] > 0 ends

		else if(dcos[2] < 0.0f) // hits either lower half or bottom of cylinder
		 {
		  // if photon travels in -Z direction staright, then it should get detected
		  if ((fabs(dcos[0]-0.0f) < epsilon) && (fabs(dcos[1]-0.0f) < epsilon) && (fabs(dcos[2] - (-1.0f)) < epsilon))  
		   {
			d = (-H/2.0f - pos[2])/dcos[2];  
			pos[2] = -H/2.0f;
				
			pos[0] = temp_pos[0] + d*dcos[0];
			pos[1] = temp_pos[1] + d*dcos[1];
		   }
		  else
		   {

			// calculate distance to infinite plane at z=-H/2
			d_plane = (-H/2.0f - pos[2])/(dcos[2]);

			// calculate the distance to the lower half of the cylinder
			if(d1 >= d2) 
			{
				d_cyl = d1;
			}
			else if(d2 > d1)
			{
				d_cyl = d2;
			}
		

			// find min from d_plane and d_cyl
			if(d_plane >= d_cyl)
			 {
				d = d_cyl;
				pos[2] = temp_pos[2] + d*dcos[2];
			 }
			else
			 {
				d = d_plane;		
				pos[2] = -H/2.0f;
			 }

			pos[0] = temp_pos[0] + d*dcos[0];
			pos[1] = temp_pos[1] + d*dcos[1];

		   }	// else loop ends

		 }	// else if loop for dcos[2] < 0 ends

		else	// when dcos[2]=0.0 (will hit only the side of the cylinder)
		 {
			// calculate the distance to the side of cylinder
			if(d1 >= d2) 
			{
				d_cyl = d1;
			}
			else if(d2 > d1)
			{
				d_cyl = d2;
			}
		
		
			d = d_cyl;
			pos[2] = temp_pos[2] + d*dcos[2];

			pos[0] = temp_pos[0] + d*dcos[0];
			pos[1] = temp_pos[1] + d*dcos[1];

		 }

		// condition to check that pos is within detector boundaries - if true, photon LOST
		if ( (pos[0] < epsilon) || (pos[0] > xdetector) || (pos[1] < epsilon) || (pos[1] > ydetector) || (pos[2] < -H/2.0f) || (pos[2] > H/2.0f)  )
			{
				d = -99.0f;
				num_lost++;
				goto distexit;
			}
		else
			{
				if(isfinite(d) != 0)
					photon_distance = photon_distance + d;		// add distance travelled to global variable
			}	


		// check if photon is outside of current column. This can happen due to single precision errors. If yes, then move the photon towards the column based on the 'stepsize' and check again. Repeat this 100 times, if still outside then kill the photon.
		R1 = sqrt((pos[0] - Xc)*(pos[0] - Xc) + (pos[1] - Yc)*(pos[1] - Yc));
		
		repeat = 0;
		ctr1 = 0;

		while( (R1 > (R-1e-5)) && (repeat < 10) && (ctr1 < 10) ) // R1 > R1-some small value..because of single precision errors that comparison with R may generate
		{

			// store current position
			temp_pos[0] = pos[0];
			temp_pos[1] = pos[1];

			// move photon by 0.5 um in the incident direction
			pos[0] = pos[0] + stepsize*(-dcos[0]);
			pos[1] = pos[1] + stepsize*(-dcos[1]);

			R2 = sqrt((pos[0] - Xc)*(pos[0] - Xc) + (pos[1] - Yc)*(pos[1] - Yc));

			if(R2 > R1) // means the photon is moving farther away from the column 
			{	    // this can happen if the stepsize is big enough for the photon to pass through the column and exit on other side.

				// move it back to previous position, reduce the stepsize and try moving it again.
				pos[0] = temp_pos[0];
				pos[1] = temp_pos[1];

				stepsize = stepsize/2.0f;
				ctr1++;
			}
			else
			{
				R1 = R2;
				repeat++;
			}

		}

		// kill the photon if still outside the column
		if(R1 > (R-1e-5))
		 {
			d = -99.0f;
			num_outofcol++;
			goto distexit;
		 }

		// condition to check that pos is within detector boundaries - if true, photon LOST
		if ( (pos[0] < epsilon) || (pos[0] > xdetector) || (pos[1] < epsilon) || (pos[1] > ydetector) || (pos[2] < -H/2.0f) || (pos[2] > H/2.0f)  )
			{
				d = -99.0f;
				num_lost++;
				goto distexit;
			}

	distexit:
	 return d;
	}
	

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// calculate the directional cosines of the reflected vector
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int boundary_analysis(float *normal, float *pos, float *dcos, int* seed, float xdetector, float ydetector, float R, float H, float n1, float n2, float top_absfrac, float beta, 	float d_min, int pixelsize, float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, struct start_info info, float d_max, 
	float sensorRefl, int ydim, int *h_num_detected_prim)
	{

		float dcos_temp[3] = {0.0f};
		float Pr = 0.0f, Pt = 0.0f;	// Probability of reflection and transmission
		float theta1 = 0.0f;		// angle between normal and reflected vector (radians)
		float theta2 = 0.0f;		// angle between normal and transmitted vector (radians)
		float cct1 = 0.0f;		// columnar crosstalk
		int trans_flag = 0.0f;		// flag - photon terminated during transmission to a new column; used in transmit() (terminated: yes=1; no=0)
		int flag_abs = 0;		// flag - photon absorbed at the top surface (yes=1; no=0)
		int flag_call_transmit = 1;	// flag - photon moves within a column (flag = 0) [call isotropic()] or between columns (flag = 1) [call transmit()]
		int flagCCT = 0;		// flag - photon cross over (yes=1; no=0); send as input to transmit()
		int newnormalctr=0;		// counter - if angle between inverted dir. cosine and rough normal > 1.57 or < 0 radians (recalculate normal; max. 100 times)
		int theta1ctr=0;		// counter - if theta1 > 1.57 or < 0 radians (recalculate normal; max. 100 times)
		int oldN_Rctr=0;		// counter - if angle between reflected dir. cosine and smooth normal > 1.57 radians (recalculate max. 25 times)
		int reperturb_ctr = 0;		// counter - if angle between reflected dir. cosine and rough normal > 1.57 radians (reperturb normal; max. 3 times)
		float newdepth = 0.0f;		// bottom depth for which CCT=1 (z_a)
		float temp_norm = 0.0f;
		float mag = 0.0f;
		float rr_rnd = 0.0f, theta_rnd = 0.0f;
		float old_normal[3] = {0.0f};
		float old_dcos[3] = {0.0f};
		float angle_oldN_R = 0.0f;
		float cos_newangle = 0.0f, newangle = 0.0f;


		// determine the coordinates of normal
		if ( (fabs(pos[2] - (float)(H/2.0f)) < epsilon) && (dcos[2] > 0.0f) )	// reached top surface and dir. cosine in z-direction is positive
		{
	
			if ( (top_absfrac > 0.0f) && (ranecu(seed) < top_absfrac) )	// photon gets absorbed; 'top_absfrac' is the top surface absorption fraction (0,1)
			{
				flag_abs = 1;
				num_abs_top++;						// increment # photons absorbed at the top surface
			}
			else
			{
				normal[0] = 0.0f;
				normal[1] = 0.0f;
				normal[2] = -1.0f;

				// assign new directional cosines; top surface is isotropic reflector
				dcos[2] = -fabs((ranecu(seed) * 2.0f) - 1.0f);
				rr_rnd = sqrt(1.0f - dcos[2]*dcos[2]);
				theta_rnd = ranecu(seed)*twopipen;	

				dcos[0]=rr_rnd*cos(theta_rnd);
				dcos[1]=rr_rnd*sin(theta_rnd);
	
				flag_abs = 0;
			}

		}	
		else 	// photon reflected or transmitted
		{	
			// Columnar crosstalk
			newdepth = H*0.2f;	// top 20% depth CCT=1. considering CsI layer only. NO organic polymer coating.
		
			if( (pos[2] <= H/2.0f) && (pos[2] >= (H/2.0f - newdepth)) )	// top 20% - 100% cct
			{
				cct1 = 1.0f;
			}
			else if( (pos[2] < (H/2.0f - newdepth)) && (pos[2] >= 0.0f) )  // from 20% depth to 50% - linear 100% to 50% 
			{
				cct1 = (pos[2]/(2.0f*(H/2.0f - newdepth))) + 0.5;	
			}
			else if( (pos[2] < 0.0f) && (pos[2] >= (-H/2.0f)) ) // bottom 50% to (-H/2 - 4 um polymer) - 50% to 100% CCT
			{
				cct1 = ( (pos[2] - (-H/2.0f))/(2.0f * (-H/2.0f)) ) + 1.0 ;
			}

	
			if(ranecu(seed) < cct1)		// columnar crosstalk occurs
			{

				// photon crosses over to adjacent column with random orientation. directional cosine do not change.
				flagCCT = 1;

				trans_flag = transmit(pos, dcos, normal, seed, xdetector, ydetector, H, top_absfrac, beta, d_min, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, myimage, info, d_max, sensorRefl, ydim, flagCCT, h_num_detected_prim);

				if (trans_flag == 1)		// photon terminated
					flag_abs = 1;
				else if (trans_flag == 0)	// photon still alive; crossed over to adjacent column
				{
					// calculate new column's center coordinates
					Xc = (float)( pos[0] + R*(-normal[0]) );
					Yc = (float)( pos[1] + R*(-normal[1]) );

					flag_abs = 0;
				}
			}
			else
			{

			prpt:

				// within the column
				if(flag_call_transmit == 1)			// photon is currently within a column with center Xc,Yc
				{
					mag = sqrt( (((Xc)-pos[0]) * ((Xc)-pos[0])) + (((Yc)-pos[1]) * ((Yc)-pos[1])) );
					normal[0] = ((Xc)-pos[0])/mag;
					normal[1] = ((Yc)-pos[1])/mag;
					normal[2] = 0.0f;
		
					if(beta > 0.0f)
						RoughSurface(normal, seed, beta);	// perturb normal for rough surface according to 'beta'

					flag_abs = 0;
				}
				// outside the column
				else if (flag_call_transmit == 0)		// photon is currently between columns and has not entered any column yet. New normal is sampled in the transmit(), so do not calculate normal here.
				{
					// center of new column (obtained by inverting the new normal sampled in transmit() and finding center at distance R from current position)
					Xc = (float)( pos[0] + R*(-normal[0]) );
					Yc = (float)( pos[1] + R*(-normal[1]) );

				        flag_abs = 0;
				}

				dcos_temp[0] = -dcos[0];	// -dcos -> invert the incident dcos vector; to get the smaller angle between normal and dcos
				dcos_temp[1] = -dcos[1];
				dcos_temp[2] = -dcos[2];

				old_normal[0] = normal[0];
				old_normal[1] = normal[1];
				old_normal[2] = normal[2];
	
				old_dcos[0] = dcos[0];
				old_dcos[1] = dcos[1];
				old_dcos[2] = dcos[2];

			reperturb:
				normal[0] = old_normal[0];
				normal[1] = old_normal[1];
				normal[2] = old_normal[2];

				dcos[0] = old_dcos[0];
				dcos[1] = old_dcos[1];
				dcos[2] = old_dcos[2];

				dcos_temp[0] = -dcos[0];
				dcos_temp[1] = -dcos[1];
				dcos_temp[2] = -dcos[2];

				if( (flag_call_transmit == 1) && (reperturb_ctr != 0) )		// within the column
				 {
					if(beta > 0.0f)
						RoughSurface(normal, seed, beta);	
				 }
				if( (flag_call_transmit == 0) && (reperturb_ctr != 0) )		// outside the column
				 {
					if(beta > 0.0f)
						RoughSurface(normal, seed, beta);	

					// center of new column (obtained by inverting the new normal sampled in transmit() and finding center at distance R from current position)
					Xc = (float)( pos[0] + R*(-normal[0]) );
					Yc = (float)( pos[1] + R*(-normal[1]) );

				 }
			
				// Using Snell's law, calculate theta1 (angle between normal and reflected) and theta2 (angle between normal and transmitted)
			no_perturbation:
				theta1 = dot_product(dcos_temp,normal);		// cosine of angle between incident in opposite direction and normal (in radians)

		
				if ( (theta1 > 1.0f) || (theta1 < 0.0f) )	// if incidence angle > 1.57 or < 0 radians, then recalculate normal
				{
					// if photon was transmitted, then new normal has to be sampled again
					if(flag_call_transmit == 0)
					{
					mynewnormal:
						normal[0] = dcos_temp[0];		// normal = inverted dir. cosine of the incident vector
						normal[1] = dcos_temp[1];
						normal[2] = dcos_temp[2];

						RoughSurface(normal, seed, 1.0f);	// beta = 1.0 to get new normal within +-1.57 radians of inverted dcos.

						mag = sqrt(normal[0]*normal[0] + normal[1]*normal[1]);

						// make z component of normal equal to 0.0f and renormalize (because we want to rotate the normal only in the x-y plane)
						normal[2] = 0.0f;			// normal_z of a cylinder is zero (no tilt assumed)
						normal[0] = normal[0]/mag;		
						normal[1] = normal[1]/mag;

						if(beta > 0.0f)
							RoughSurface(normal, seed, beta);

						// find the angle between normal and -dcos
						cos_newangle = dot_product(dcos_temp, normal);
						newangle = acosf(cos_newangle);

						if ( (newangle < 0.0f) || (newangle > 1.57f) )	// new normal within +- 1.57 radians from inverted dcos
						{						// keep looping until get a theta within 1.57 radians - maximum iterations 100
							if(newnormalctr < 100)
							{
								newnormalctr++;
								goto mynewnormal;			
							}
							else 					// else terminate photon
							{
								num_theta1++;
								flag_abs = 1;
								newnormalctr = 0;
								goto baexit;
							}				
						}

					}


					if(theta1ctr < 100)	// recalculate max. 100 times
					{
						theta1ctr++;
						goto prpt;
					}
					else			// terminate photon
					{
						num_theta1++;	// increment the counter for 'theta1' - # photons terminated due to incidence angle > 1.57 or < 0 radian
						flag_abs = 1;
						theta1ctr = 0;
						goto baexit;
					}
				}
				else		// 0< theta1 < 1.57 radians; continue photon transport
					theta1 = acosf(theta1);
		

				// check for conditions where photon can only reflect
				if (flag_call_transmit == 1)	// only valid when photon within the column and can transmit outside the column. asin(n1/n2) -> nan
				{
					if (theta1 > asin(n2/n1))	// critical angle condition for total internal reflection (TIR)
					{
						Pr = 1.0f;		// TIR occurs
						Pt = 0.0f;
					}
			       		else if ( theta1 < epsilon ) 	// theta1 ~= 0, then always reflect
					{
				        	theta1 = 0.00042;       // make theta1 a very small number, to avoid getting nan probabilities
					        theta2 = asinf((float)(n1/n2)*sin(theta1));     // refracted/transmitted angle in radians

					        // Using Fresnel's law, compute probability of reflection and transmission 
					        Pr = 1/2.0f*( (pow(tan(theta1-theta2),2)/pow(tan(theta1+theta2),2)) + (pow(sin(theta1-theta2),2)/pow(sin(theta1+theta2),2)) );
				        	Pt = 1/2.0f*( ((sin(2.0f*theta1)*sin(2.0f*theta2))/(pow(sin(theta1+theta2),2)*pow(cos(theta1-theta2),2))) + ((sin(2.0f*theta1)*sin(2.0f*theta2))/pow(sin(theta1+theta2),2)) );
					}
					else    // the ray will transmit
					{
				        	theta2 = asinf((float)(n1/n2)*sin(theta1));     // refracted/transmitted angle in radians
					        
					        // Using Fresnel's law, compute probability of reflection and transmission 
				        	Pr = 1/2.0f*( (pow(tan(theta1-theta2),2)/pow(tan(theta1+theta2),2)) + (pow(sin(theta1-theta2),2)/pow(sin(theta1+theta2),2)) );
					        Pt = 1/2.0f*( ((sin(2.0f*theta1)*sin(2.0f*theta2))/(pow(sin(theta1+theta2),2)*pow(cos(theta1-theta2),2))) + ((sin(2.0f*theta1)*sin(2.0f*theta2))/pow(sin(theta1+theta2),2)) );
					}

				}
				else if (flag_call_transmit == 0)	// outside the column
				{		
					if((n1/n2) < 1.57f)	
					{
						if (theta1 > asin(n1/n2))	// critical angle condition for total internal reflection (TIR)
						{
							Pr = 1.0f;		// TIR occurs
							Pt = 0.0f;
						}
					}
					else if ( theta1 < epsilon )	// theta1 ~= 0, then always reflect
					{
						theta1 = 0.00042;	// make theta1 a very small number, to avoid getting nan probabilities
						theta2 = asinf((float)(n1/n2)*sin(theta1)); 	// refracted/transmitted angle in radians
	
						// Using Fresnel's law, compute probability of reflection and transmission 
						Pr = 1/2.0f*( (pow(tan(theta1-theta2),2)/pow(tan(theta1+theta2),2)) + (pow(sin(theta1-theta2),2)/pow(sin(theta1+theta2),2)) );
						Pt = 1/2.0f*( ((sin(2.0f*theta1)*sin(2.0f*theta2))/(pow(sin(theta1+theta2),2)*pow(cos(theta1-theta2),2))) + ((sin(2.0f*theta1)*sin(2.0f*theta2))/pow(sin(theta1+theta2),2)) );
					}
					else	// photon transmits
					{
						theta2 = asinf((float)(n2/n1)*sin(theta1));

						// Using Fresnel's law, compute probability of reflection and transmission 
						Pr = 1/2.0f*( (pow(tan(theta1-theta2),2)/pow(tan(theta1+theta2),2)) + (pow(sin(theta1-theta2),2)/pow(sin(theta1+theta2),2)) );
						Pt = 1/2.0f*( ((sin(2.0f*theta1)*sin(2.0f*theta2))/(pow(sin(theta1+theta2),2)*pow(cos(theta1-theta2),2))) + ((sin(2.0f*theta1)*sin(2.0f*theta2))/pow(sin(theta1+theta2),2)) );
					}

				}


				// normalize Pr and Pt
				temp_norm = Pr + Pt;
				Pr = Pr/temp_norm;
				Pt = Pt/temp_norm;


				if(ranecu(seed) < Pr)				// reflection
				{
					trans_dir_cos(dcos, normal, theta1, theta2, 0, info);  // compute reflected directional cosines


					// condition to check that reflected vector is within 1.57 radians from original normal
					angle_oldN_R = dot_product(old_normal, dcos);
					angle_oldN_R = acosf(angle_oldN_R);


					if (angle_oldN_R > 1.57f) // > 1.57 radians, reperturb the normal
					{
						reperturb_ctr++;

						if(reperturb_ctr < 4)		// maximum 3 times reperturb
							goto reperturb;
						else				// calculate using smooth surface normal (old_normal)
						{
							normal[0] = old_normal[0];
							normal[1] = old_normal[1];
							normal[2] = old_normal[2];

							dcos[0] = old_dcos[0];
							dcos[1] = old_dcos[1];
							dcos[2] = old_dcos[2];

							dcos_temp[0] = -dcos[0];
							dcos_temp[1] = -dcos[1];
							dcos_temp[2] = -dcos[2];

							reperturb_ctr = 0;

							if(oldN_Rctr < 25)	// max resample 25 times (25*3 reperturb = 75 times)
							{
								oldN_Rctr++;
								goto no_perturbation;
							}
							else			// terminate photon
							{
								num_theta1++;	// increment the counter for 'theta1' - # photons terminated due to incidence angle > 1.57 or < 0 radian
								flag_abs = 1;
								oldN_Rctr = 0;
								goto baexit;
							}
						}
					}

					if (flag_call_transmit == 0)		// reflects between columns, calculate distance using transmit()
					{
						flagCCT = 0;

						trans_flag = transmit(pos, dcos, normal, seed, xdetector, ydetector, H, top_absfrac, beta, d_min, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, myimage, info, d_max, sensorRefl, ydim, flagCCT, h_num_detected_prim);

						if (trans_flag == 1)		// photon terminated
							flag_abs = 1;
						else if (trans_flag == 0)
							goto prpt;				
					}
				}
				else						// transmission
				{
					trans_dir_cos(dcos, normal, theta1, theta2, 1, info);	// compute transmitted directional cosines

					if (flag_call_transmit == 1)		// photon exits current column
					{
						flag_call_transmit = 0;
						flagCCT = 0;

						trans_flag = transmit(pos, dcos, normal, seed, xdetector, ydetector, H, top_absfrac, beta, d_min, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, myimage, info, d_max, sensorRefl, ydim, flagCCT, h_num_detected_prim);

						if (trans_flag == 1)		// photon terminated
							flag_abs = 1;
						else if (trans_flag == 0)	// hits a column
							goto prpt;		// check again to see if it gets reflected or transmitted
					}			
				}

			} // else prpt ends

		}	// else ends

	baexit:
	   return flag_abs;

	}	


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Photon gets transmitted, calculate the new position where it hits next column or boundary
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int transmit(float *pos, float *dcos, float *normal, int* seed, float xdetector, float ydetector, float H, float top_absfrac, float beta, float d_min, int pixelsize, 
	float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, struct start_info info, float d_max, float sensorRefl, int ydim, int flagCCT, 		int *h_num_detected_prim)
	{
		float d_nextCol = 0.0f;		// distance to next column	
		float d_top = 0.0f;		// distance to top surface
		float d_bottom = 0.0f;		// distance to bottom surface
		int photon_exit = 0;		// flag - photon terminates (lost/detected/absorbed) (yes=1; no=0)
		int reflbtm = 0;		// flag - photon terminated during call to refl_bottom() (yes=1; no=0)
		int newnormalctr = 0;		// counter - if angle between inverted dir. cosine and rough normal > 1.57 or < 0 radians (recalculate normal; max. 100 times)
		int newnormalctr2 = 0;
		float newangle = 0.0f;
		float cos_newangle = 0.0f;
		float temp_pos[3] = {0.0f};
		float temp_dcos[3] = {0.0f};
		float rr_rnd = 0.0f, theta_rnd = 0.0f;
		float tmp_deno = 0.0f;
		int iii = 0, jjj = 0;


		temp_pos[0] = pos[0];
		temp_pos[1] = pos[1];
		temp_pos[2] = pos[2];

		temp_dcos[0] = -dcos[0];	// inverted directional cosine - used to calculate angle between incident vector and normal
		temp_dcos[1] = -dcos[1];
		temp_dcos[2] = -dcos[2];

		if(flagCCT == 1)	// columnar crosstalk occurs
		{
			// cross over to adjacent column. no change in dir. cosines. d_nextcol = 0. adjacent column has random orientation.
			newnormal1:
				normal[0] = temp_dcos[0];		// invert dcos of incident vector
				normal[1] = temp_dcos[1];
				normal[2] = temp_dcos[2];

				RoughSurface(normal, seed, 1.0f);	// beta = 1.0 to get new normal within +-1.57 radians of inverted dcos.

				tmp_deno = sqrt(normal[0]*normal[0] + normal[1]*normal[1]);

				// make z component of normal equal to 0.0f and renormalize (because we want to rotate the normal only in the x-y plane)
				normal[2] = 0.0f;			// normal_z of a cylinder is zero (no tilt assumed)
				normal[0] = normal[0]/tmp_deno;		
				normal[1] = normal[1]/tmp_deno;

				// perturb the normal according to Beta
				if(beta > 0.0f)
					RoughSurface(normal, seed, beta);

				// find the angle between Normal and -Dcos
				cos_newangle = dot_product(temp_dcos, normal);
				newangle = acosf(cos_newangle);

				if ( (newangle < 0.0f) || (newangle > 1.57f) )	// check if new normal is within +- 1.57 radians from inverted dcos
				 {						// keep looping until 'newangle' within 1.57 radians (max. 100 times)
					if(newnormalctr < 100)
					{
						newnormalctr++;
						goto newnormal1;			
					}
					else 					// terminate photon
					{
						num_theta1++;
						photon_exit = 1;
						newnormalctr = 0;
						goto exitnow;
					}
						
				 }

				photon_exit = 0;	// photon still alive
		}
		else		// no columnar crosstalk occurs
		{

			// sample distance uniformly between d_min and d_max to next column
			d_nextCol = ranecu(seed) * (d_max - d_min) + d_min;

			// new position of the photon. 
			pos[0] = temp_pos[0] + dcos[0] * d_nextCol;
			pos[1] = temp_pos[1] + dcos[1] * d_nextCol;
			pos[2] = temp_pos[2] + dcos[2] * d_nextCol;

			d_top = ((H/2.0f) - temp_pos[2])/dcos[2];
			d_bottom  = ((-H/2.0f) - temp_pos[2])/dcos[2];

			// condition to check that pos is within detector boundaries - if true, photon LOST
			if ( (pos[0] < epsilon) || (pos[0] > xdetector) || (pos[1] < epsilon) || (pos[1] > ydetector) )
			{
				num_lost++;
				photon_exit = 1;
				goto exitnow;
			}

			if ( (pos[2] < -H/2.0f) || (pos[2] > H/2.0f)  )
				{
					if( (d_top < d_nextCol) && (d_top > epsilon) )	// d_top < d_nextCol: photon reflects from the top surface
					{
						pos[0] = temp_pos[0] + dcos[0] * d_top;
						pos[1] = temp_pos[1] + dcos[1] * d_top;
						pos[2] = H/2.0f;
				
						if(isfinite(d_top) != 0)
							photon_distance = photon_distance + d_top;
						photon_exit = 0;			
					}
					else if( (d_bottom < d_nextCol) && (d_bottom > epsilon) )	// d_bottom < d_nextCol: photon detected.
					{
						pos[0] = temp_pos[0] + dcos[0] * d_bottom;
						pos[1] = temp_pos[1] + dcos[1] * d_bottom;
						pos[2] = -H/2.0f;

						if(isfinite(d_bottom) != 0)
							photon_distance = photon_distance + d_bottom;

						// non-ideal sensor - reflects back sensorRefl% of photons into the current column; detects rest
						if(ranecu(seed) < sensorRefl)	// reflect back - specular (mirror) reflection
						{
		
							photon_exit = 0;

							// normal pointing +z-direction
							normal[0] = 0.0f; normal[1] = 0.0f; normal[2] = 1.0f;

							// obtain reflected dcos from the bottom (specular reflection; 
							// bottom surface is smooth, do not perturb the normal)
							trans_dir_cos(dcos, normal, 0.0f, 0.0f, 0, info);	// reflection only so 'refl_theta,trans_theta' = 0

							// sample new distance and place new column there
							reflbtm = refl_bottom(pos, dcos, normal, xdetector, ydetector, seed, beta, d_min, H, d_max);

							if(reflbtm == 1)
							{
								photon_exit = 1;	// photon terminated in refl_bottom()
								goto exitnow;
							}


							// hits top surface after reflecting back?
							if ( (fabs(pos[2] - (H/2.0f)) < epsilon) && (dcos[2] > 0.0f) )	
							{
								goto mytopsurface;
							}

						}
						else	// not reflected back into column; photon detected
						{
							photon_exit = 1;	
							num_detect++;

							iii = floor((pos[0]-lbound_x)/pixelsize);	// x,y pixel number in the sensor plane of the detector
							jjj = floor((pos[1]-lbound_y)/pixelsize);

							// if the photon gets detected within lower and upper bounds: accumulate the signal contribution
							if( (pos[0] <= ubound_x) && (pos[1] <= ubound_y) && (pos[0] >= lbound_x) && (pos[1] >= lbound_y) )
							 {	
								myimage[iii*ydim + jjj]++;
							 }

							h_num_detected_prim[info.str_histnum-1]++;	// increment # detected per primary
				
							goto exitnow;
						}	
					}
					else	// terminate photon
					{
						num_lost++;
						photon_exit = 1;
						goto exitnow;
					}
				}
			else		// photon lies between top and bottom surfaces of detector
			 {
				if(isfinite(d_nextCol) != 0) 
					photon_distance = photon_distance + d_nextCol;		// add distance to mean free path of photon
			 }


			// sample new normal to determine orientation of new column.
		newnormal:
			normal[0] = temp_dcos[0];		// invert dcos of incident vector
			normal[1] = temp_dcos[1];
			normal[2] = temp_dcos[2];

			RoughSurface(normal, seed, 1.0f);	// beta = 1.0 to get new normal within +-1.57 radians of inverted dcos.

			tmp_deno = sqrt(normal[0]*normal[0] + normal[1]*normal[1]);

			// make z component of normal equal to 0.0f and renormalize (because we want to rotate the normal only in the x-y plane)
			normal[2] = 0.0f;			// normal_z of a cylinder is zero (no tilt assumed)
			normal[0] = normal[0]/tmp_deno;		
			normal[1] = normal[1]/tmp_deno;

			// perturb the normal according to Beta
			if(beta > 0.0f)
				RoughSurface(normal, seed, beta);

			// angle between normal and -dcos
			cos_newangle = dot_product(temp_dcos, normal);
			newangle = acosf(cos_newangle);

			if ( (newangle < 0.0f) || (newangle > 1.57f) )	// check if new normal is within +- 1.57 radians from inverted dcos
			 {						// keep looping until 'newangle' within 1.57 radians (max. 100 iterations)
				if(newnormalctr < 100)
				{
					newnormalctr++;
					goto newnormal;			
				}
				else 					// terminate photon
				{
					num_theta1++;
					photon_exit = 1;
					newnormalctr = 0;
					goto exitnow;
				}
						
			 }
	
			// check if the photon enters another column or gets lost (hit detector side)/ reflected (detector top)/ detected (detector bottom)
	
			// hits side of detector?
			if ( (fabs(pos[0]-0.0f) < epsilon) || (fabs(pos[0]-xdetector) < epsilon) || (fabs(pos[1]-0.0f) < epsilon) || (fabs(pos[1]-ydetector) < epsilon) )		
			{
				num_lost++;
				photon_exit = 1;
				goto exitnow;

			}


			// hit top?
		     mytopsurface:

			if ( (fabs(pos[2] - (H/2.0f)) < epsilon) && (dcos[2] > 0.0f) )	// gets reflected or absorbed
			{
				normal[0] = 0.0f;
				normal[1] = 0.0f;
				normal[2] = -1.0f;

				if ( (top_absfrac > 0.0f) && (ranecu(seed) < top_absfrac) )	// photon gets absorbed at top surface
				{
					num_abs_top++;
					photon_exit = 1;
					goto exitnow;
				}
				else	// photon reflected from top
				{
					// assign new directional cosines (isotropic top surface)
					dcos[2] = -fabs((ranecu(seed) * 2.0f) - 1.0f);
					rr_rnd = sqrt(1.0f - dcos[2]*dcos[2]);
					theta_rnd = ranecu(seed)*twopipen;	
	
					dcos[0]=rr_rnd*cos(theta_rnd);
					dcos[1]=rr_rnd*sin(theta_rnd);

					temp_pos[0] = pos[0];
					temp_pos[1] = pos[1];
					temp_pos[2] = pos[2];

					temp_dcos[0] = -dcos[0];
					temp_dcos[1] = -dcos[1];
					temp_dcos[2] = -dcos[2];

					// sample distance uniformly between d_min and d_max to next column
					d_nextCol = ranecu(seed) * (d_max - d_min) + d_min;

					// distance to bottom surface: if d_bottom < d_nextCol, photon detected.
					d_bottom  = ((-H/2.0f) - temp_pos[2])/dcos[2];

					// compute the new position of the photon. 
					pos[0] = temp_pos[0] + dcos[0] * d_nextCol;
					pos[1] = temp_pos[1] + dcos[1] * d_nextCol;
					pos[2] = temp_pos[2] + dcos[2] * d_nextCol;

					// check new position is within detector boundaries? - if false, photon lost
					if ( (pos[0] < epsilon) || (pos[0] > xdetector) || (pos[1] < epsilon) || (pos[1] > ydetector) )
					{
						num_lost++;
						photon_exit = 1;
						goto exitnow;
					}

					if ( (pos[2] < -H/2.0f) || (pos[2] > H/2.0f)  )
						{
							if( (d_bottom < d_nextCol) && (d_bottom > epsilon) )
							{
								pos[0] = temp_pos[0] + dcos[0] * d_bottom;
								pos[1] = temp_pos[1] + dcos[1] * d_bottom;
								pos[2] = -H/2.0f;

								if(isfinite(d_bottom) != 0)
									photon_distance = photon_distance + d_bottom;

								// non-ideal sensor - reflects back sensorRefl% of photons into the current column; absorbs rest
								if(ranecu(seed) < sensorRefl)	// reflect back - specular (mirror) reflection
								{

									photon_exit = 0;		
			
									// normal pointing (0,0,1)
									normal[0] = 0.0f; normal[1] = 0.0f; normal[2] = 1.0f;

									// obtain reflected dcos from the bottom (specular reflection; 
									// bottom surface is smooth, do not perturb the normal)
									trans_dir_cos(dcos, normal, 0.0f, 0.0f, 0, info);	// reflection only so 'refl_theta,trans_theta' = 0

									// sample new distance and place new column
									reflbtm = refl_bottom(pos, dcos, normal, xdetector, ydetector, seed, beta, d_min, H, d_max);

									if(reflbtm == 1)
									{
										photon_exit = 1;
										goto exitnow;
									}

									// hits top surface after reflecting back?
									if ( (fabs(pos[2] - (H/2.0f)) < epsilon) && (dcos[2] > 0.0f) )	
									{
										goto mytopsurface;
									}

								}
								else		// not reflected back into column; detected
								{
										photon_exit = 1;
										num_detect++;

										iii = floor((pos[0]-lbound_x)/pixelsize);	// x,y pixel number
										jjj = floor((pos[1]-lbound_y)/pixelsize);

										// photon gets detected within lower and upper bounds: accumulate signal contribution
										if( (pos[0] <= ubound_x) && (pos[1] <= ubound_y) && (pos[0] >= lbound_x) && (pos[1] >= lbound_y) )
										 {	
											myimage[iii*ydim + jjj]++;
										 }

										h_num_detected_prim[info.str_histnum-1]++;	// increment # detected per primary

										goto exitnow;	
								}	
							}
							else	// terminate photon
							{
								num_lost++;
								photon_exit = 1;
								goto exitnow;
							}
						}
					else
					{
						if(isfinite(d_nextCol) != 0)
							photon_distance = photon_distance + d_nextCol;		// add distance to mean free path of photon
					}	

					// sample new normal to determine orientation of new column.
			  newnormal_TOP:
					normal[0] = temp_dcos[0];		// invert dcos of incident vector
					normal[1] = temp_dcos[1];
					normal[2] = temp_dcos[2];

					RoughSurface(normal, seed, 1.0f);	// beta = 1.0 to get new normal within +-1.57 radians of inverted dcos.

					tmp_deno = sqrt(normal[0]*normal[0] + normal[1]*normal[1]);

					// make z component of normal equal to 0.0f and renormalize (because we want to rotate the normal only in the x-y plane)
					normal[2] = 0.0f;			// normal_z of a cylinder is zero (no tilt assumed)
					normal[0] = normal[0]/tmp_deno;		
					normal[1] = normal[1]/tmp_deno;

					// perturb the normal according to Beta
					if(beta > 0.0f)
						RoughSurface(normal, seed, beta);

					// angle between normal and -dcos
					cos_newangle = dot_product(temp_dcos, normal);
					newangle = acosf(cos_newangle);

					if ( (newangle < 0.0f) || (newangle > 1.57f) )	// new normal within +- 1.57 radians from inverted dcos
					 {						// keep looping until 'newangle' within 1.57 radians (max. 100 iterations)
						if(newnormalctr2 < 100)	
						{
							newnormalctr2++;
							goto newnormal_TOP;			
						}
						else 					// terminate photon
						{
							num_theta1++;
							photon_exit = 1;
							newnormalctr2 = 0;
							goto exitnow;
						}
				
					 }
		
					photon_exit = 0;	// photon still alive
				}
			}	// hit top ends
	

			// hit bottom? 
			if ( fabs(pos[2] - (-H/2.0f)) < epsilon )	// gets detected
			{
				// non-ideal sensor - reflects back sensorRefl% of photons into the current column; absorbs rest
				if(ranecu(seed) < sensorRefl)	// reflect back - specular (mirror) reflection
				{
					photon_exit = 0;		
	
					// normal pointing (0,0,1)
					normal[0] = 0.0f; normal[1] = 0.0f; normal[2] = 1.0f;

					// obtain reflected dcos from the bottom (specular reflection; 
					// bottom surface is smooth, do not perturb the normal)
					trans_dir_cos(dcos, normal, 0.0f, 0.0f, 0, info);	// reflection only so 'refl_theta,trans_theta' = 0

					// sample new distance and place new column
					reflbtm = refl_bottom(pos, dcos, normal, xdetector, ydetector, seed, beta, d_min, H, d_max);

					if(reflbtm == 1)
					{
						photon_exit = 1;
						goto exitnow;
					}

					// hits top surface after reflecting back?
					if ( (fabs(pos[2] - (H/2.0f)) < epsilon) && (dcos[2] > 0.0f) )	
					{
						goto mytopsurface;
					}

				}
				else		// detected
				{
					num_detect++;
					photon_exit = 1;

					iii = floor((pos[0]-lbound_x)/pixelsize);	// x,y pixel number in sensor plane of detector
					jjj = floor((pos[1]-lbound_y)/pixelsize);

					// photon gets detected within lower and upper bounds: accumulate the signal contribution
					if( (pos[0] <= ubound_x) && (pos[1] <= ubound_y) && (pos[0] >= lbound_x) && (pos[1] >= lbound_y) )
					 {	
						myimage[iii*ydim + jjj]++;
					 }

					h_num_detected_prim[info.str_histnum-1]++;	// increment # detected per primary
	
					goto exitnow;
				}
			}

		} // else flagCCT ends

	exitnow:
	 return photon_exit;	
	}
	

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// photon reflects from sensor_plane or bottom surface, when in between columns. 
// Obtains the next column where it hits.
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int refl_bottom(float *pos, float *dcos, float *normal, float xdetector, float ydetector, int* seed, float beta, float d_min, float H, float d_max)
	{
		float d_nextCol=0.0f;	// distane to next column
		float d_top=0.0f;	// distance to top surface of detector
		int pexit=0;		// flag - photon ternimated in this function call (exited: yes=1; no=0)
		int newnormalctr = 0;	// counter - angle between inverted dir. cosine and rough normal > 1.57 or < 0 radians (recalculate max. 100 times)
		float temp_pos[3], temp_dcos[3];
		float tmp_deno=0.0f, cos_newangle=0.0f, newangle=0.0f;


		temp_pos[0] = pos[0];
		temp_pos[1] = pos[1];
		temp_pos[2] = pos[2];

		temp_dcos[0] = -dcos[0];		// inverted directional cosines - used to calculate angle between incident and normal vectors
		temp_dcos[1] = -dcos[1];
		temp_dcos[2] = -dcos[2];

		// sample distance uniformly between d_min and d_max to next column
		d_nextCol = ranecu(seed) * (d_max - d_min) + d_min;

		// distance to top surface
		d_top  = ((H/2.0f) - temp_pos[2])/dcos[2];

		// compute the new position of the photon. 
		pos[0] = temp_pos[0] + dcos[0] * d_nextCol;
		pos[1] = temp_pos[1] + dcos[1] * d_nextCol;
		pos[2] = temp_pos[2] + dcos[2] * d_nextCol;

		// is new position is within detector boundaries? if false, photon lost
		if ( (pos[0] < epsilon) || (pos[0] > xdetector) || (pos[1] < epsilon) || (pos[1] > ydetector) )
		{
			num_lost++;	// increment # photons lost
			pexit = 1;
			goto myexit;
		}

		if ( (pos[2] > H/2.0f)  )		// photon's new z position is above top surface
		{
				if( (d_top < d_nextCol) && (d_top > epsilon) )		// if distance to top < dist. to next column; photon will hit top surface
				{
					pos[0] = temp_pos[0] + dcos[0] * d_top;
					pos[1] = temp_pos[1] + dcos[1] * d_top;
					pos[2] = H/2.0f;
				
					if(isfinite(d_top) != 0)
						photon_distance = photon_distance + d_top;	// add this distance to mean free path of photon
					pexit = 0;			
				}
				else			// terminate photon
				{
					num_lost++;
					pexit = 1;
					goto myexit;
				}
		}
		else
		{
			if(isfinite(d_nextCol) != 0)	
				photon_distance = photon_distance + d_nextCol;		// add distance to mean free path of photon

			// sample new normal to determine orientation of new column.
		  	mynewnormal:

				normal[0] = temp_dcos[0];		// invert incident directional cosines
				normal[1] = temp_dcos[1];
				normal[2] = temp_dcos[2];

				RoughSurface(normal, seed, 1.0f);	// beta = 1.0 to get new normal within +-1.57 radians of inverted dcos.

				tmp_deno = sqrt(normal[0]*normal[0] + normal[1]*normal[1]);

				// make z component of normal equal to 0.0f and renormalize (because we want to rotate the normal only in the x-y plane)
				normal[2] = 0.0f;			// normal_z of a cylinder is zero (no tilt assumed)
				normal[0] = normal[0]/tmp_deno;		
				normal[1] = normal[1]/tmp_deno;

				// perturb the normal according to Beta
				RoughSurface(normal, seed, beta);

				// angle between Normal and -Dcos
				cos_newangle = dot_product(temp_dcos, normal);
				newangle = acosf(cos_newangle);

				if ( (newangle < 0.0f) || (newangle > 1.57f) )	// check if new normal is within +- 1.57 radians from inverted dcos
				 {
					if(newnormalctr < 100)	// max 100 times
					{
						newnormalctr++;
						goto mynewnormal;			// keep looping until 'newangle' within 1.57 radians	
					}
					else 			// terminate photon
					{
						num_theta1++;	// increment the counter for 'theta1' - # photons terminated due to incidence angle > 1.57 or < 0 radian
						pexit = 1;
						newnormalctr = 0;
						goto myexit;
					}		
				 }
				pexit = 0;	// photon still alive
		}

	myexit:
	 return pexit;
	}
	

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// calculate dot product of two vectors
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	float dot_product(float *aa, float *b)
	{
		float result = 0.0f;

		result = aa[0]*b[0] + aa[1]*b[1] + aa[2]*b[2];

	  return result;
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// compute directional cosines of transmitted vector
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	void trans_dir_cos(float *dcos, float *normal, float refl_theta, float trans_theta, int flag_ref, struct start_info info)
	{
		float cos_angle = 0.0f;
		float norm = 0.0f;
		float dcos_temp[3] = {0.0f};

		dcos_temp[0] = -dcos[0];	// inverted directional cosines - used to calculate angle between incident and normal vectors
		dcos_temp[1] = -dcos[1];
		dcos_temp[2] = -dcos[2];
	
		cos_angle = dot_product(dcos_temp,normal);	// cosine of angle between inverted incident dir. cosine and normal

		if (flag_ref == 0)				// reflection
		{
				dcos[0] = 2.0f*cos_angle*normal[0] + dcos[0];  // specular reflection
				dcos[1] = 2.0f*cos_angle*normal[1] + dcos[1];
				dcos[2] = 2.0f*cos_angle*normal[2] + dcos[2];
		}
		else if (flag_ref == 1)				// transmission	
		{
			 dcos[0]= -normal[0]*cos(trans_theta)-(sin(trans_theta)/sin(refl_theta))*(dcos[0]+(cos_angle*normal[0]));
			 dcos[1]= -normal[1]*cos(trans_theta)-(sin(trans_theta)/sin(refl_theta))*(dcos[1]+(cos_angle*normal[1]));
			 dcos[2]= -normal[2]*cos(trans_theta)-(sin(trans_theta)/sin(refl_theta))*(dcos[2]+(cos_angle*normal[2]));
		}

		// normalize
		norm = sqrt(dcos[0]*dcos[0] + dcos[1]*dcos[1] + dcos[2]*dcos[2]);

		if ((norm < (1.0f - epsilon)) || (norm > (1.0f + epsilon)))
		 {
			dcos[0] = dcos[0]/norm;
			dcos[1] = dcos[1]/norm;
			dcos[2] = dcos[2]/norm;
		 } 

	return;	
	}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// add roughness to the surface of the column according to roughness coefficient 'beta'
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	void RoughSurface(float *normal, int* seed, float beta)
	{
		float theta = 0.0f;
		float status = 0.0f;
		float rr = 0.0f;
		float normalpert[3] = {0.0f};
		float rough_normal[3] = {0.0f};
		float normalize_base = 0.0f;

		// generate the perturbation vector
		status = ranecu(seed);
		normalpert[2] = 2.0f*status - 1.0f;	// random number between (-1,1)
		rr = sqrt(1.0f - status*status);
		status = ranecu(seed);
		theta = status * 2.0f * pi;		// random number between (0,2pi)

		normalpert[0] = rr * cos(theta);
		normalpert[1] = rr * sin(theta);

		// normalize the perturbed vector
		normalize_base = sqrt( pow(normalpert[0],2) + pow(normalpert[1],2) + pow(normalpert[2],2) );
	
		normalpert[0] = normalpert[0]/normalize_base;
		normalpert[1] = normalpert[1]/normalize_base;
		normalpert[2] = normalpert[2]/normalize_base;

		// rough normal = beta*perturbed + original normal
		rough_normal[0] = beta * normalpert[0] + normal[0];	
		rough_normal[1] = beta * normalpert[1] + normal[1];
		rough_normal[2] = beta * normalpert[2] + normal[2];

		// normalize rough normal
		normalize_base = sqrt( pow(rough_normal[0],2) + pow(rough_normal[1],2) + pow(rough_normal[2],2) );

		normal[0] = rough_normal[0]/normalize_base; 
		normal[1] = rough_normal[1]/normalize_base;
		normal[2] = rough_normal[2]/normalize_base;

	return;
	}	


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// determine if the photon gets detected
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int detection(float *pos, float H, int pixelsize, float lbound_x, float lbound_y, float ubound_x, float ubound_y, unsigned long long int *myimage, struct start_info info, 
	float sensorRefl, float d_min, int* seed, float *dcos, float *normal, float bulk_abscoeff, float R, float xdetector, float ydetector, unsigned long long int mynum_rebound, 
	int ydim, int *h_num_detected_prim)
	{

		int result = 0;		// flag - photon detected at sensor plane or absorbed in the bulk
		int absflag = 0;	// flag - photon absorbed in the bulk (yes=1; no=0); returned from isotropic
		int ii = 0, jj = 0;	// x,y pixel number for detected photons


		// if z = -H/2 (sensor plane), photon detected
		if (fabs(pos[2] - (float)(-H/2.0f)) < epsilon) 
		 {
			if(ranecu(seed) < sensorRefl)		// non-ideal sensor - reflects back sensorRefl% of photons into the current column; detects rest
			{

				// normal pointing +z-direction
				normal[0] = 0.0f; 
				normal[1] = 0.0f; 
				normal[2] = 1.0f;

				// reflected dir. cosine from the sensor plane (bottom surface) (bottom surface is smooth, no need to perturb the normal; specular reflection)
				trans_dir_cos(dcos, normal, 0.0f, 0.0f, 0, info); // reflection only, so 'refl_theta, trans_theta' = 0

				// using above calculated dir. cosine, move the photon within the column
				absflag = isotropic(pos, dcos, seed, bulk_abscoeff, R, H, xdetector, ydetector, info, mynum_rebound);

				if(absflag == 1)	// absorbed in bulk
					result = 1;
				else
					result = 0;

			}
			else					// photon detected  
			{
				result = 1;
				num_detect++;
		
				ii = floor((pos[0]-lbound_x)/pixelsize);	// x,y pixel number in the sensor plane of the detector
				jj = floor((pos[1]-lbound_y)/pixelsize);

				// if the photon gets detected within lower and upper bounds of PRF: accumulate the signal contribution
				if( (pos[0] <= ubound_x) && (pos[1] <= ubound_y) && (pos[0] >= lbound_x) && (pos[1] >= lbound_y) )
				 {	
					myimage[ii*ydim + jj]++;
				 }

				h_num_detected_prim[info.str_histnum-1]++;	// increment # detected per primary (the history number starts from 0, but it has to go at 0th element of array, thus -1 in the end)
			}
			 
		 }
		else
		    	result = 0;
	  
	 return result;
	}


////////////////////////////////////////////////////////////////////////////////
//! Initialize the pseudo-random number generator (PRNG) RANECU to a position
//! far away from the previous history (leap frog technique).
//!
//! Each calculated seed initiates a consecutive and disjoint sequence of
//! pseudo-random numbers with length LEAP_DISTANCE, that can be used to
//! in a parallel simulation (Sequence Splitting parallelization method).
//! The basic equation behind the algorithm is:
//!    S(i+j) = (a**j * S(i)) MOD m = [(a**j MOD m)*S(i)] MOD m  ,
//! which is described in:
//!   P L'Ecuyer, Commun. ACM 31 (1988) p.742
//!
//! This function has been adapted from "seedsMLCG.f", see:
//!   A Badal and J Sempau, Computer Physics Communications 175 (2006) p. 440-450
//!
//!       @param[in] history   Particle bach number.
//!       @param[in] seed_input   Initial PRNG seed input (used to initiate both MLCGs in RANECU).
//!       @param[out] seed   Initial PRNG seeds for the present history.
//!
////////////////////////////////////////////////////////////////////////////////
// -- Upper limit of the number of random values sampled in a single track:
#define  LEAP_DISTANCE    1000
// -- Multipliers and moduli for the two MLCG in RANECU:
#define  a1_RANECU       40014
#define  m1_RANECU  2147483563
#define  a2_RANECU       40692
#define  m2_RANECU  2147483399

	void init_PRNG(int history_batch, int histories_per_thread, int seed_input, int* seed)
	{
	  // -- Move the RANECU generator to a unique position for the current batch of histories:
	  //    I have to use an "unsigned long long int" value to represent all the simulated histories in all previous batches
	  //    The maximum unsigned long long int value is ~1.8e19: if history >1.8e16 and LEAP_DISTANCE==1000, 'leap' will overflow.
	  // **** 1st MLCG:
	  unsigned long long int leap = ((unsigned long long int)(history_batch+1))*(histories_per_thread*LEAP_DISTANCE);
	  int y = 1;
	  int z = a1_RANECU;
	  // -- Calculate the modulo power '(a^leap)MOD(m)' using a divide-and-conquer algorithm adapted to modulo arithmetic
	  for(;;)
	  {
	      // printf(" leap, leap>>1, leap&1: %d, %d, %d\n",leap, leap>>1, leap&1);  

	    // (A2) Halve n, and store the integer part and the residue
	    if (0!=(leap&01))  // (bit-wise operation for MOD(leap,2), or leap%2 ==> proceed if leap is an odd number)  !!DeBuG!! OLD: t=(short)(leap%2);
	    {
	      leap >>= 1;     // Halve n moving the bits 1 position right. Equivalent to:  leap=(leap/2); 
	      y = abMODm(m1_RANECU,z,y);      // (A3) Multiply y by z:  y = [z*y] MOD m
	      if (0==leap) break;         // (A4) leap==0? ==> finish
	    }
	    else           // (leap is even)
	    {
	      leap>>= 1;     // Halve leap moving the bits 1 position right. Equivalent to:  leap=(leap/2);
	    }
	    z = abMODm(m1_RANECU,z,z);        // (A5) Square z:  z = [z*z] MOD m
	  }
	  // AjMODm1 = y;                 // Exponentiation finished:  AjMODm = expMOD = y = a^j

	  // -- Compute and display the seeds S(i+j), from the present seed S(i), using the previously calculated value of (a^j)MOD(m):
	  //         S(i+j) = [(a**j MOD m)*S(i)] MOD m
	  //         S_i = abMODm(m,S_i,AjMODm)
	  seed[0] = abMODm(m1_RANECU, seed_input, y);     // Using the input seed as the starting seed

	  // **** 2nd MLCG (repeating the previous calculation for the 2nd MLCG parameters):
	  leap = ((unsigned long long int)(history_batch+1))*(histories_per_thread*LEAP_DISTANCE);
	  y = 1;
	  z = a2_RANECU;
	  for(;;)
	  {
	    // (A2) Halve n, and store the integer part and the residue
	    if (0!=(leap&01))  // (bit-wise operation for MOD(leap,2), or leap%2 ==> proceed if leap is an odd number)  !!DeBuG!! OLD: t=(short)(leap%2);
	    {
	      leap >>= 1;     // Halve n moving the bits 1 position right. Equivalent to:  leap=(leap/2); 
	      y = abMODm(m2_RANECU,z,y);      // (A3) Multiply y by z:  y = [z*y] MOD m
	      if (0==leap) break;         // (A4) leap==0? ==> finish
	    }
	    else           // (leap is even)
	    {
	      leap>>= 1;     // Halve leap moving the bits 1 position right. Equivalent to:  leap=(leap/2);
	    }
	    z = abMODm(m2_RANECU,z,z);        // (A5) Square z:  z = [z*z] MOD m
	  }
	  // AjMODm2 = y;
	  seed[1] = abMODm(m2_RANECU, seed_input, y);     // Using the input seed as the starting seed

	}

/////////////////////////////////////////////////////////////////////
//!  Calculate "(a1*a2) MOD m" with 32-bit integers and avoiding   **
//!  the possible overflow, using the Russian Peasant approach     **
//!  modulo m and the approximate factoring method, as described   **
//!  in:  L'Ecuyer and Cote, ACM Trans. Math. Soft. 17 (1991)      **
//!                                                                **
//!  This function has been adapted from "seedsMLCG.f", see:       **
//!  Badal and Sempau, Computer Physics Communications 175 (2006)  **
//!                                                                **
//!    Input:          0 < a1 < m                                  **
//!                    0 < a2 < m                                  **
//!                                                                **
//!    Return value:  (a1*a2) MOD m                                **
//!                                                                **
/////////////////////////////////////////////////////////////////////

	int abMODm(int m_par, int a_par, int s_par)
	{
	  // CAUTION: the input parameters are modified in the function but should not be returned to the calling function! (pass by value!)   !!DeBuG!!
	  int mval,aval,sval;
	  mval=m_par; aval=a_par; sval=s_par;
	  
	  int qval, kval;
	  int pval = -mval;            // p is always negative to avoid overflow when adding

	  // ** Apply the Russian peasant method until "a =< 32768":
	  while (aval>32768)        // We assume '32' bit integers (4 bytes): 2^(('32'-2)/2) = 32768
	  {
	    if (0!=(aval&1))        // Store 's' when 'a' is odd    !!DeBuG!! OLD code:   if (1==(a%2))
	    {
	      pval += sval;
	      if (pval>0) pval -= mval;
	    }
	    aval >>= 1;             // Half a (move bits 1 position right)        
	    sval = (sval-mval) + sval;       // float s (MOD m)
	    if (sval<0) sval += mval;     // (s is always positive)
	  }

	  // ** Employ the approximate factoring method (a is small enough to avoid overflow):
	  qval = (int) mval / aval;
	  kval = (int) sval / qval;
	  sval = aval*(sval-kval*qval)-kval*(mval-qval*aval);
	  while (sval<0)
	    sval += mval;

	  // ** Compute the final result:
	  pval += sval;
	  if (pval<0) pval += mval;

	  return pval;
	}

////////////////////////////////////////////////////////////////////////////////
//! Pseudo-random number generator (PRNG) RANECU returning a float value
//! (single precision version).
//!
//!       @param[in,out] seed   PRNG seed (seed kept in the calling function and updated here).
//!       @return   PRN double value in the open interval (0,1)
//!
////////////////////////////////////////////////////////////////////////////////

	float ranecu(int* seed)
	{
	  int i1 = (int)(seed[0]/53668);
	  seed[0] = 40014*(seed[0]-i1*53668)-i1*12211;

	  int i2 = (int)(seed[1]/52774);
	  seed[1] = 40692*(seed[1]-i2*52774)-i2*3791;

	  if (seed[0] < 0) seed[0] += 2147483563;
	  if (seed[1] < 0) seed[1] += 2147483399;

	  i2 = seed[0]-seed[1];
	  if (i2 < 1) i2 += 2147483562;

	  const float USCALE = 1.0/2147483563.0;       
	  return ((float)(i2*USCALE));

	}

