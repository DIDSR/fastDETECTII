///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
// 			     //////////////////////////////////////////////////////////
//  			     //							     //
// 			     //   	       fastDETECT2 - C code  		     //
//			     //		   (optical photons transport)		     //
//			     //							     //
//			     //////////////////////////////////////////////////////////
//
// 
//
//
// ****Disclaimer****
//  This software and documentation (the "Software") were developed at the Food and Drug Administration (FDA) by employees of the Federal Government in
//  the course of their official duties. Pursuant to Title 17, Section 105 of the United States Code, this work is not subject to copyright protection
//  and is in the public domain. Permission is hereby granted, free of charge, to any person obtaining a copy of the Software, to deal in the Software
//  without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, or sell copies of the
//  Software or derivatives, and to permit persons to whom the Software is furnished to do so. FDA assumes no responsibility whatsoever for use by other
//  parties of the Software, its source code, documentation or compiled executables, and makes no guarantees, expressed or implied, about its quality,
//  reliability, or any other characteristic. Further, use of this code in no way implies endorsement by the FDA or confers any advantage in regulatory
//  decisions. Although this software can be redistributed and/or modified freely, we ask that any derivative works bear some notice that they are
//  derived from it, and any modified versions bear some notice that they have been modified. 
//
//
//	Associated publication: Sharma Diksha, Badal Andreu and Badano Aldo, "hybridMANTIS: a CPU-GPU Monte Carlo method for modeling indirect x-ray detectors with
//				columnar scintillators". Physics in Medicine and Biology, 57(8), pp. 2357–2372 (2012)
//
//
//	File:   	fastDETECT2.c 			
//	Author: 	Diksha Sharma (US Food and Drug Administration)
//	Email: 		diksha.sharma@fda.hhs.gov			
//	Last updated:  	Mar 12, 2015
// 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////
//
//      Header libraries
//
/////////////////////////////////////////

	#include <gsl/gsl_rng.h>
	#include <gsl/gsl_randist.h>

/////////////////////////////////////////
//
//      Global variables
//
/////////////////////////////////////////

	#define max_photon_per_EDE 900000	// maximum number of optical photons that can be generated per energy deposition event (EDE)

/////////////////////////////////////////
//
//      Include kernel program
//
/////////////////////////////////////////

	#include "kernel.c"

////////////////////////////////////////////////////////////////////////////
//				MAIN PROGRAM			          //
////////////////////////////////////////////////////////////////////////////

	int main(int argc, char *argv[])
	 {    

		// command line arguments
		float xdetector, ydetector, radius, height, n_C, n_IC, top_absfrac, bulk_abscoeff, beta, d_min, lbound_x, lbound_y, ubound_x, ubound_y, d_max, yield, sensorRefl;
		int pixelsize, num_primary, min_optphotons, max_optphotons, num_bins, seed_input;
		long int final_counter;
		char input_fname[80];
		char input_fname1[80];
		char input_fname2[80];
		char input_fname3[80];

		float dcos[3]={0}; 		// directional cosines
		float normal[3]={0}; 		// normal to surface in case of TIR
		float pos[3] = {0}; 		// intersecting point coordinates
		float old_pos[3] = {0};  	// source coordinates
	
		int nbytes = 200000*sizeof(struct start_info);	// memory bytes for storing energy deposition events. Assuming there are maximum 2000 per primary
		struct start_info *structa;
		structa = (struct start_info*) malloc(nbytes);
		if( structa == NULL )
			printf("\n Struct start_info array CANNOT BE ALLOCATED!!");

		// aggregate counters (statistics for all x-ray histories)
		unsigned long long int agg_num_generated=0;	
		unsigned long long int agg_num_detect=0;	
		unsigned long long int agg_num_abs_top=0;	
		unsigned long long int agg_num_abs_bulk=0;	
		unsigned long long int agg_num_lost=0;	
		unsigned long long int agg_num_outofcol=0;	 
		unsigned long long int agg_num_theta1=0;
		float agg_photon_distance=0.0f; 	// average photon distance travelled among all the optical photons

		// get time
		 clock_t start_t, end_t;
		 double total_t;

		// get current time stamp to initialize seed input for RNG
		time_t seconds;
		seconds = time (NULL);
		struct timeval tv;
		gettimeofday(&tv,NULL);

		float rr=0.0f, theta=0.0f;	
		float r=0.0f;			// random number
		float norm=0.0f;
		int jj=0;
		int my_index=0;
		int penindex = 0;		// equal to *gpusize
		int result_algo = 0;
		unsigned long long int *num_rebound;

		// variable for random number generator (RANECU)
		int seed[2], RNGindex=0;

		// GNU scientific library (gsl) variables
		const gsl_rng_type * Tgsl;
		gsl_rng * rgsl;
		double mu_gsl;	
				
		// output image variables
		int xdim = 0;
		int ydim = 0;
		int indexi=0, indexj=0;

		// check number of arguments inputted
		if((argc-1) < 13)
		{
			printf("\t Insufficient arguments!! 13 arguments required !! \n\n");
			printf("**************************************************************************************\n");
			printf("\t PROGRAM EXITING !!!\n\n");
			fflush(stdout);
			exit(0);
		}

		// start clock()
		start_t = clock();

		// copy to local variables from PENELOPE buffers
//		xdetector = atof(argv[1]);		// x dimension of detector (in um). x in (0,xdetector)  
//		ydetector = atof(argv[2]);		// y dimension of detector (in um). y in (0,ydetector)
		height = atof(argv[1]);			// height of column and thickness of detector (in um). z in range (-H/2, H/2)
		radius = atof(argv[2]);			// radius of column (in um).
//		n_C = atof(argv[5]);			// refractive index of columns
//		n_IC = atof(argv[6]);			// refractive index of intercolumnar material
		top_absfrac = atof(argv[3]);		// column's top surface absorption fraction (0.0, 0.5, 0.98)
		bulk_abscoeff = atof(argv[4]);		// column's bulk absorption coefficient (in um^-1) (0.001, 0.1 cm^-1) 
		beta = atof(argv[5]);			// roughness coefficient of column walls
//		d_min = atof(argv[10]);			// minimum distance a photon can travel when transmitted from a column (in um)
//		d_max = atof(argv[11]);			// maximum distance a photon can travel when transmitted from a column (in um)
//		lbound_x = atof(argv[12]);		// x lower bound of region of interest of output image (in um)
//		lbound_y = atof(argv[13]);		// y lower bound (in um)
//		ubound_x = atof(argv[14]);		// x upper bound (in um) 
//		ubound_y = atof(argv[15]);		// y upper bound (in um)
//		yield = atof(argv[16]);			// yield (/eV)
//		pixelsize = atoi(argv[17]);		// 1 pixel = pixelsize microns (in um)
		sensorRefl = atof(argv[6]);		// Non-Ideal sensor reflectivity (%)
		num_primary = atoi(argv[7]);		// total number of primaries to be simulated
//		min_optphotons = atoi(argv[20]);	// minimum number of optical photons detected to be included in PHS
//		max_optphotons = atoi(argv[21]);	// maximum number of optical photons detected to be included in PHS
		num_bins = atoi(argv[8]);		// number of bins for genrating PHS
		seed_input = atoi(argv[9]);		// ranecu seed input
		strcpy(input_fname,argv[10]);		// Scintillation events file name - specifying the deposition locations and energy
		strcpy(input_fname1,argv[11]);		// PRF filename
		strcpy(input_fname2,argv[12]);		// PHS filename
		strcpy(input_fname3,argv[13]);		// # optical photons detected/primary filename


		// initialize rest of the parameters
		xdetector = 909.0f;
		ydetector = 909.0f;
		n_C = 1.8f;
		n_IC = 1.0f;
		d_min = 1.0f;
		d_max = 280.0f;
		lbound_x = 0.0f;
		lbound_y = 0.0f;
		ubound_x = 909.0f;
		ubound_y = 909.0f;
		yield = 0.055;
		pixelsize = 9;
		min_optphotons = 0;
		max_optphotons = 5000;

		// open files
		FILE *fpin, *fpprf, *fpphs, *fpdpp;
		fpin = fopen(input_fname,"rt");
		if(fpin == NULL)
			printf("\n Cannot open energy deposition events file (%s) for reading!\n", input_fname);
		
		fpprf = fopen(input_fname1,"wt");
		if(fpprf == NULL)
			printf("\n Cannot open PRF file for writing!\n");


		fpphs = fopen(input_fname2,"wt");
		if(fpphs == NULL)
			printf("\n Cannot open PHS file for writing!\n");

		fpdpp = fopen(input_fname3,"wt");
		if(fpdpp == NULL)
			printf("\n Cannot open detected/primary file for writing!\n");

		fflush(stdout);

		char new_line[250];		// used in reading from input file
		char *new_line_ptr;
		char first_char = 'd';
		int rows_read = 0;
		int ii=0;

	    // create a generator chosen by the environment variable GSL_RNG_TYPE
	    	gsl_rng_env_setup();	     
	       	Tgsl = gsl_rng_default;
	       	rgsl = gsl_rng_alloc (Tgsl);
       	
	       	// dimensions of PRF image
		xdim = ceil((ubound_x - lbound_x)/pixelsize);
		ydim = ceil((ubound_y - lbound_y)/pixelsize);
		unsigned long long int myimage[xdim][ydim];
		unsigned long long int agg_myimage[xdim][ydim];
			
		//initialize the output image 2D array
		for(indexi = 0; indexi < xdim; indexi++)
		{ 
		 for(indexj = 0; indexj < ydim; indexj++)
		 {
		  myimage[indexi][indexj] = 0;
		  agg_myimage[indexi][indexj] = 0;
		 }
		}
	
		// memory for storing histogram of # photons detected/primary
		int *h_num_detected_prim = 0;		
		h_num_detected_prim = (int*)malloc(sizeof(int)*num_primary);
				
		for(indexj=0; indexj < num_primary; indexj++)
		  h_num_detected_prim[indexj] = 0;
		  		  
		  	
		// memory for storing histogram of # photons detected/primary
		int *h_histogram = 0;		
		h_histogram = (int*)malloc(sizeof(int)*num_bins);
			
		for(indexj=0; indexj < num_bins; indexj++)
		  h_histogram[indexj] = 0;


	for(my_index = 0; my_index < num_primary; my_index++)		// iterate over x-rays
	{

		// read ede events from file into *structa
		first_char = 'd';
		rows_read = 0;	

		do{
			new_line_ptr = fgets(new_line, 250, fpin);
			first_char = new_line[0];
			if ( (strcmp(new_line, " \n") != 0) && (first_char != '#') )		// discard empty lines and comments
			{
				// line of data
				sscanf(new_line, "%lf %lf %lf %lf %d",&structa[rows_read].str_x, &structa[rows_read].str_y, &structa[rows_read].str_z, &structa[rows_read].str_E, &structa[rows_read].str_histnum);

				// units in the penelope output file are in cm. Convert them to microns.
				structa[rows_read].str_x = structa[rows_read].str_x * 10000.0f;	// x-coordinate of interaction event
				structa[rows_read].str_y = structa[rows_read].str_y * 10000.0f;	// y-coordinate
				structa[rows_read].str_z = structa[rows_read].str_z * 10000.0f;	// z-coordinate

				
				// sample # optical photons based on light yield and energy deposited for this interaction event (using Poisson distribution)
				mu_gsl = (double)structa[rows_read].str_E * yield;
				structa[rows_read].str_N = gsl_ran_poisson(rgsl,mu_gsl);
	
				if(structa[rows_read].str_N > max_photon_per_EDE)
				{
					printf("\n\n str_n exceeds max photons. program is exiting - %d !! \n\n",structa[rows_read].str_N);
					exit(0);
				}
				rows_read++;	// increment number of rows read from the file
			}
		  }while(first_char != '#');	// read until reach "# past hist" line


		// reset the global counters
		num_generated = 0;
		num_detect=0;
		num_abs_top=0;	
		num_abs_bulk=0;	
		num_lost=0;
		num_outofcol=0;
		num_theta1=0;
		photon_distance=0.0f;

		// re-initialize myimage and detected/primary arrays
		for(indexi = 0; indexi < xdim; indexi++)
		 for(indexj = 0; indexj < ydim; indexj++)
			  myimage[indexi][indexj] = 0;
			  
		
		for(ii = 0; ii < rows_read; ii++)		// iterate over energy deposition events
		 {	

			num_rebound = (unsigned long long int*) malloc(structa[ii].str_N*sizeof(unsigned long long int));
			if(num_rebound == NULL)
			printf("\n Error allocating num_rebound memory !\n");

			for(jj = 0; jj < structa[ii].str_N; jj++)
				num_rebound[jj] = 0;

	
			// initialize the RANECU generator in a position far away from the previous history:
			RNGindex = (int)(seconds/3600+tv.tv_usec);			// equal to seconds passed since 1970+current time in micro secs
			init_PRNG(RNGindex, 50000, seed_input, seed);      		// intialize RNG
		
			// reset the directional cosine and normal vectors
			dcos[0]=0.0f; dcos[1]=0.0f; dcos[2]=0.0f;
			normal[0]=0.0f; normal[1]=0.0f; normal[2]=0.0f;
				
			// set starting location of photon
			pos[0] = structa[ii].str_x; pos[1] = structa[ii].str_y; pos[2] = structa[ii].str_z;	
			old_pos[0] = structa[ii].str_x; old_pos[1] = structa[ii].str_y; old_pos[2] = structa[ii].str_z;

			// initializing the direction cosines for the first particle in each core
			r = (ranecu(seed) * 2.0f) - 1.0f; 	// random number between (-1,1)
			 	
			while(fabs(r) <= 0.01f)	
			 {
			   	r = (ranecu(seed) * 2.0f) - 1.0f;  	
			 }

			dcos[2] = r;		// random number between (-1,1)
			rr = sqrt(1.0f-r*r);
			theta=ranecu(seed)*twopipen;
			dcos[0]=rr*cos(theta);
			dcos[1]=rr*sin(theta);

			norm = sqrt(dcos[0]*dcos[0] + dcos[1]*dcos[1] + dcos[2]*dcos[2]);

			if ((norm < (1.0f - epsilon)) || (norm > (1.0f + epsilon)))	// normalize
			 {
				dcos[0] = dcos[0]/norm;
				dcos[1] = dcos[1]/norm;
				dcos[2] = dcos[2]/norm;
			 }


			local_counter=0;	// total number of photons terminated (either detected at sensor, absorbed at the top or in the bulk) [global variable]
			while(local_counter < structa[ii].str_N)		// until all the optical photons are not transported for current energy deposition event
			 { 
			
				absorbed = 0;
				detect = 0;
				bulk_abs = 0;

				// set starting location of photon
				pos[0] = structa[ii].str_x; pos[1] = structa[ii].str_y; pos[2] = structa[ii].str_z;	
				old_pos[0] = structa[ii].str_x; old_pos[1] = structa[ii].str_y; old_pos[2] = structa[ii].str_z;
				num_generated++;
				result_algo = 0;

				while(result_algo == 0)
				 {
				  	result_algo = algo(normal, old_pos, pos, dcos, num_rebound, seed, structa[ii], &myimage[0][0], xdetector, ydetector, radius, height, n_C, n_IC, top_absfrac, bulk_abscoeff, beta, d_min, pixelsize, lbound_x, lbound_y, ubound_x, ubound_y, sensorRefl, d_max, ydim, h_num_detected_prim);      
				 }

			 }	

					
			// release resources
			free(num_rebound);

		 } //rows_read loop ends
			
		// aggregate them to counters - add statistics for current x-ray history to aggregate counters
		agg_num_generated = agg_num_generated + num_generated;
		agg_num_detect = agg_num_detect + num_detect;	
		agg_num_abs_top = agg_num_abs_top + num_abs_top;	
		agg_num_abs_bulk = agg_num_abs_bulk + num_abs_bulk;	
		agg_num_lost = agg_num_lost + num_lost;	
		agg_num_outofcol = agg_num_outofcol + num_outofcol;	 
		agg_num_theta1 = agg_num_theta1 + num_theta1;
		agg_photon_distance = agg_photon_distance + photon_distance;


		for(indexi = 0; indexi < xdim; indexi++)
		 for(indexj = 0; indexj < ydim; indexj++)
		  {
			  agg_myimage[indexi][indexj] = agg_myimage[indexi][indexj] + myimage[indexi][indexj];
		  }
		  
			
	}	// my_index loop ends
	
	// make histogram of number of detected photons/primary for num_bins
	int binsize=0, newbin=0;
	int bincorr=0;
							
	binsize = floor((max_optphotons-min_optphotons)/num_bins);	// calculate size of each bin. Assuming equally spaced bins.
	bincorr = floor(min_optphotons/binsize);			// correction in bin number if min_optphotons > 0.
			
		
	for(indexi = 0; indexi < num_primary; indexi++)
	 {
	 	newbin = floor(h_num_detected_prim[indexi]/binsize) - bincorr;	// find bin #
		 	
	 	if(h_num_detected_prim[indexi] > 0)	// store only non-zero bins
	 	{
		 	if(h_num_detected_prim[indexi] <= min_optphotons)	// # detected < minimum photons given by user, add to the first bin
		 		h_histogram[0]++;
		 	else if(h_num_detected_prim[indexi] >= max_optphotons)	// # detected > maximum photons given by user, then add to the last bin
		 		h_histogram[num_bins-1]++;
		 	else
		 		h_histogram[newbin]++; 
		}
	 }
			
	
	// write PRF and PHS to files
	int kk=0, mm=0;

	for(kk = 0; kk < num_bins; kk++)
		fprintf(fpphs,"%d\n", h_histogram[kk]);

	for(kk = 0; kk < num_primary; kk++)
		fprintf(fpdpp,"%d\n", h_num_detected_prim[kk]);

	for(kk = 0; kk < xdim; kk++)
	 {
		 for(mm = 0; mm < ydim; mm++)
		  {
			fprintf(fpprf,"%lld\n", agg_myimage[kk][mm]);
		  }
		fprintf(fpprf,"\n");
	 }


		// end clock()
		end_t = clock();	// get time in clocks. To get seconds, divide by CLOCKS_PER_SEC
		total_t = (double)(end_t - start_t)/CLOCKS_PER_SEC;
		
	// print statistics
	printf("\n\n********************************************************************");
	printf("\n\t\tOPTICAL TRANSPORT STATISTICS");
	printf("\n********************************************************************");
	printf("\n\tTotal number of photons:");
	printf("\n\t\t Generated: \t\t %lld", agg_num_generated);
	printf("\n\t\t Detected: \t\t %lld", agg_num_detect);
	printf("\n\t\t Absorbed at top: \t %lld", agg_num_abs_top);
	printf("\n\t\t Absorbed in bulk: \t %lld", agg_num_abs_bulk);
	printf("\n\t\t Lost at the boundary: \t %lld", agg_num_lost);
	printf("\n\t Average path length (microns):  %f", ((float)agg_photon_distance/agg_num_generated));
	printf("\n\t Total time (seconds): \t\t %lf", total_t);
	printf("\n\t Speed (primaries/seconds): \t %lf", ((double)num_primary/total_t));		
	printf("\n********************************************************************\n\n");
		

	// release resources
	free(structa);
	free(h_num_detected_prim);
	free(h_histogram);

	return 0;

	}	// main() ends
	

